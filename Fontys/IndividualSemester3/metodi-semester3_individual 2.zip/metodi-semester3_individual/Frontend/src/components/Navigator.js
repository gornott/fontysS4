import * as React from 'react';
import Divider from '@mui/material/Divider';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import Box from '@mui/material/Box';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import AutoStoriesIcon from '@mui/icons-material/AutoStories';
import PeopleIcon from '@mui/icons-material/People';
import LoginIcon  from '@mui/icons-material/Login';
import LogOutIcon  from '@mui/icons-material/Logout';
import {NavLink, useNavigate} from "react-router-dom";
import AuthService from "../services/auth-service";
import {useState} from "react";
import { ToastContainer} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import authService from "../services/auth-service";
import ChatIcon from "@mui/icons-material/Chat";
const user = authService.getUserId();
const categories = [
    {
        id: 'Main',
        children: [
            {
                id: 'Diary',
                icon: <AutoStoriesIcon />,
                active: true,
                link: `/diary/${user}`,
            },
            {
                id: 'Users',
                icon: <PeopleIcon />,
                link: '/users'
            },
            {
                id: 'Public Chat',
                icon: <ChatIcon />,
                link: '/chat'
            }
        ],
    },
    {
        id: 'Quality',
        children: [
            { id: 'LogIn', icon: <LoginIcon />,link: '/login'},
            {id: 'LogOut', icon: <LogOutIcon />},
        ],
    },
];

const item = {
    py: '2px',
    px: 3,
    color: 'rgba(255, 255, 255, 0.7)',
    '&:hover, &:focus': {
        bgcolor: 'rgba(255, 255, 255, 0.08)',
    },
};

const itemCategory = {
    boxShadow: '0 -1px 0 rgb(255,255,255,0.1) inset',
    py: 1.5,
    px: 3,
};

export default function Navigator(props) {
    const navigate = useNavigate();
    function logout(){
        AuthService.logout();
        navigate('/login');
    }

    function afterLogin(){
        if (localStorage.getItem("token") === null) {
            return (
            <ListItem disablePadding key={categories.at(1).children.at(0).id}>
                <NavLink to={categories.at(1).children.at(0).link}>
                    <ListItemButton component={NavLink} to={categories.at(1).children.at(0).link} sx={{...item, pl: 4,width:"250px"}}>
                        <ListItemIcon>{categories.at(1).children.at(0).icon}</ListItemIcon>
                        <ListItemText>{categories.at(1).children.at(0).id}</ListItemText>
                    </ListItemButton>
                </NavLink>
            </ListItem>)
        }
            return (<ListItem disablePadding key={categories.at(1).children.at(1).id}>
                <ListItemButton onClick={logout} to={categories.at(1).children.at(1).link}
                                sx={{...item, pl: 4, width: "250px"}}>

                    <ListItemIcon>{categories.at(1).children.at(1).icon}</ListItemIcon>
                    <ListItemText>{categories.at(1).children.at(1).id}</ListItemText>
                </ListItemButton>
            </ListItem>)
    }
    function afterLoginAdmin(){
        if(authService.areYouAdmin()){
            return(
                <ListItem disablePadding key={categories.at(0).children.at(1).id}>
                    <NavLink to={categories.at(0).children.at(1).link}>
                        <ListItemButton component={NavLink} to={categories.at(0).children.at(1)
                            .link} sx={{...item, pl: 4,width:"250px"}}>
                            <ListItemIcon>{categories.at(0).children.at(1).icon}</ListItemIcon>
                            <ListItemText>{categories.at(0).children.at(1).id}</ListItemText>
                        </ListItemButton>
                    </NavLink>
                </ListItem>
            )
        }
    }

    const { ...other } = props;
    return (
        <Drawer variant="permanent" {...other}>
            <List disablePadding>
                <ListItem sx={{ ...item, ...itemCategory, fontSize: 22, color: '#fff' }}>
                    MyFitnessPal
                </ListItem>
                <ListItem sx={{ ...item, ...itemCategory }}>
                    <ListItemText>Overview</ListItemText>
                </ListItem>
                <Box key={categories.at(0).id} sx={{ bgcolor: '#101F33' }}>
                    <ListItem sx={{ py: 2, px: 3 }}>
                        <ListItemText sx={{ color: '#fff' }}>{categories.at(0).id}</ListItemText>
                    </ListItem>
                    <ListItem disablePadding key={categories.at(0).children.at(0).id}>
                        <NavLink to={categories.at(0).children.at(0).link}>
                            <ListItemButton component={NavLink} to={categories.at(0).children.at(0)
                                .link} sx={{...item, pl: 4,width:"250px"}}>
                                <ListItemIcon>{categories.at(0).children.at(0).icon}</ListItemIcon>
                                <ListItemText>{categories.at(0).children.at(0).id}</ListItemText>
                            </ListItemButton>
                        </NavLink>
                    </ListItem>
                    <ListItem disablePadding key={categories.at(0).children.at(2).id}>
                        <NavLink to={categories.at(0).children.at(2).link}>
                            <ListItemButton component={NavLink} to={categories.at(0).children.at(2)
                                .link} sx={{...item, pl: 4,width:"250px"}}>
                                <ListItemIcon>{categories.at(0).children.at(2).icon}</ListItemIcon>
                                <ListItemText>{categories.at(0).children.at(2).id}</ListItemText>
                            </ListItemButton>
                        </NavLink>
                    </ListItem>

                    {afterLoginAdmin()}
                    <Divider sx={{ mt: 2 }} />
                </Box>
                <Box key={categories.at(1).id} sx={{ bgcolor: '#101F33' }}>
                    <ListItem sx={{ py: 2, px: 3 }}>
                        <ListItemText sx={{ color: '#fff' }}>{categories.at(1).id}</ListItemText>
                    </ListItem>
                    {afterLogin()}
                    <Divider sx={{ mt: 2 }} />
                </Box>
            </List>
            <ToastContainer/>
        </Drawer>
    );
}