import {useEffect, useState} from 'react';
import PerfectScrollbar from 'react-perfect-scrollbar';
import PropTypes from 'prop-types';
import TextField from '@mui/material/TextField';
import { useFormik } from 'formik';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import userService from "../../services/user.service";
import {
  Avatar,
  Box, Button,
  Card,
  Checkbox,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TablePagination,
  TableRow,
  Typography,
  IconButton
} from '@mui/material';
import axios from "axios";
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import httpCommon from "../../http-common";
import ButtonGroup from "@mui/material/ButtonGroup";
import * as Yup from "yup";
import AuthService from "../../services/auth-service";

export const CustomerListResults = ({ customers, ...rest }) => {
  const [selectedCustomerIds, setSelectedCustomerIds] = useState([]);
  const [limit, setLimit] = useState(10);
  const [page, setPage] = useState(0);
  const [open, setOpen] = useState(false);
  const [users,setUsers] = useState([]);

  const formik = useFormik({
    initialValues: {
      email: '',
      firstName: '',
      lastName: '',
      password: '',
      policy: false,
      weight: 0,
      height: 0,
      age: 0,
      gender: '',
    },
    validationSchema: Yup.object({
      email: Yup
          .string()
          .email('Must be a valid email')
          .max(255),
      firstName: Yup
          .string()
          .max(255),
      lastName: Yup
          .string()
          .max(255)
          ,
      password: Yup
          .string()
          .max(255)
          ,
      weight: Yup
          .number()
          ,
      height: Yup
          .number()
          ,
      age: Yup
          .number()
          ,
      gender:Yup
          .string()
            .max(255)
    }), onSubmit : async (values) => {

  }
  });

  const handleClose = () => {
    setOpen(false);
  };
  const handleSelectOne = (event) =>
  {
    setOpen(true);
    console.log(event.currentTarget.id);
  }

  const handleLimitChange = (event) => {
    setLimit(event.target.value);
  };

  const handlePageChange = (event, newPage) => {
    setPage(newPage);
  };

  useEffect(() => {
    axios.get("http://localhost:8080/users",
            {
          headers:{
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
          }}
        ).then(res => setUsers(res.data.accounts));
    }, []);


  console.log(users);

  return (
    <Card {...rest}>
      <PerfectScrollbar>
        <Box sx={{ minWidth: 1050 }}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell padding="checkbox">
                </TableCell>
                <TableCell>
                  Name
                </TableCell>
                <TableCell>
                  Email
                </TableCell>
                <TableCell>
                  Age
                </TableCell>
                <TableCell>
                  Gender
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {users.map((user) => (
                <TableRow
                  hover
                  key={user.id}
                  selected={selectedCustomerIds.indexOf(user.id) !== -1}
                >
                  <TableCell padding="checkbox">
                    <ButtonGroup
                        aling="left"
                        orientation="horizontal"
                        aria-label="vertical contained button group"
                    >
                    <IconButton aria-label="delete" color="error" size="medium">
                      <DeleteIcon fontSize="inherit" />
                    </IconButton>
                    <IconButton key={user.id} id={user.id} aria-label="edit" size="medium" onClick={handleSelectOne}>
                      <EditIcon fontSize="inherit" />
                    </IconButton>
                      <Dialog open={open} onClose={handleClose}>
                        <DialogTitle>Subscribe</DialogTitle>
                        <DialogContent>
                          <DialogContentText>
                            To subscribe to this website, please enter your email address here. We
                            will send updates occasionally.
                          </DialogContentText>
                          <TextField
                              autoFocus
                              margin="dense"
                              id="name"
                              label="Email Address"
                              type="email"
                              fullWidth
                              variant="standard"
                          />
                        </DialogContent>
                        <DialogActions>
                          <Button onClick={handleClose}>Change Settings</Button>
                        </DialogActions>
                      </Dialog>
                    </ButtonGroup>
                  </TableCell>
                  <TableCell>
                    <Box
                      sx={{
                        alignItems: 'center',
                        display: 'flex'
                      }}
                    >
                      <Typography
                        color="textPrimary"
                        variant="body1"
                      >
                        {user.firstName} {user.lastName}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    {user.email}
                  </TableCell>
                  <TableCell>
                    {user.age}
                  </TableCell>
                  <TableCell>
                    {user.gender}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      </PerfectScrollbar>
      <TablePagination
        component="div"
        count={users.length}
        onPageChange={handlePageChange}
        onRowsPerPageChange={handleLimitChange}
        page={page}
        rowsPerPage={limit}
        rowsPerPageOptions={[5, 10, 25]}
      />
    </Card>
  );
};

CustomerListResults.propTypes = {
  users: PropTypes.array.isRequired
};
