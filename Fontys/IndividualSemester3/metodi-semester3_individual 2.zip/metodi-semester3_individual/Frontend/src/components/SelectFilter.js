import * as React from 'react';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';

export default function BasicSelect(props) {
    const [filter, setFilter] = React.useState("");

    const handleChange = (event) => {
        setFilter(event.target.value);
        props.filter(filter);
    };

    return (
        <Box sx={{ minWidth: 120 }}>
            <FormControl sx={{ m: 1, minWidth: 120,left:370}} >
                <InputLabel id="demo-simple-select-label">Filter</InputLabel>
                <Select
                    sx={{minWidth: 180,textAlign:"left"}}
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    label="Filter"
                    value={props.filter}
                    onChange={props.handleChange}
                >
                    <MenuItem value={"asc"}>By Calories ascending</MenuItem>
                    <MenuItem value={"name"}>By Name</MenuItem>
                    <MenuItem value={"desc"}>By Calories descending</MenuItem>
                </Select>
            </FormControl>
        </Box>
    );
}