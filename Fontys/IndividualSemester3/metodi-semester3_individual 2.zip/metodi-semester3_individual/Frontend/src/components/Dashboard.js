import React from "react";
import PieChart from "./PieChart";
import { Box, Grid } from "@material-ui/core";

function Dashboard() {
    return (
        <Box>
            <Box>
                <Grid container>
                    <Grid item={true} xs={6}>
                        <PieChart />
                    </Grid>
                </Grid>
            </Box>
        </Box>
    );
}

export default Dashboard;