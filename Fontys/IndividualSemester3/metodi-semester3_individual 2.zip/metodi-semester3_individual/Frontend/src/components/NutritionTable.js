import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Cell from './NutritionCell'



export default function DenseTable(props) {

    return (
        <TableContainer component={Paper}>
            {props.filter}
            <Table sx={{ minWidth: 650 }} size="small" aria-label="a dense table">
                <TableHead>
                    <TableRow>
                        <TableCell>Meals</TableCell>
                        <TableCell align="right">Calories</TableCell>
                        <TableCell align="right">Fat&nbsp;(g)</TableCell>
                        <TableCell align="right">Carbs&nbsp;(g)</TableCell>
                        <TableCell align="right">Protein&nbsp;(g)</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {props.diets.map(post => (
                        <Cell diet={post} onRemove={props.onRemove}/>

                    ))}
                    <TableRow>
                    <TableCell component="th" scope="row"> Total </TableCell>
                    <TableCell align="right">{props.diets.map(
                        (post) => post.calories).reduce((a, b) => a + b, 0).toFixed(1)}</TableCell>
                    <TableCell align="right">{props.totalF}</TableCell>
                        <TableCell align="right">{props.totalC}</TableCell>
                        <TableCell align="right">{props.totalP}</TableCell>
                    </TableRow>
                </TableBody>
            </Table>
        </TableContainer>
    );
}
