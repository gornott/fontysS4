import './App.css';
import {Route, Routes, BrowserRouter as Router} from "react-router-dom";
import MFPbase from "./pages/MFPbase"
import Login from "./pages/LoginPage"
import Register from "./pages/RegisterPage"
import PrivateRoute from "./sections/auth/PrivateRoute";
import UsersPage from "./pages/UsersPage";
import AdminRoute from "./sections/auth/AdminRoute";
import ChatPage from "./pages/ChatPage";


function App() {

    return (
            <Router>
                <div className="App">
                <Routes>
                    <Route path="/" element={<Login/>}/>
                    <Route path="/diary/:id/" element={
                        <PrivateRoute>
                            <MFPbase/>
                        </PrivateRoute>
                    }/>
                    <Route path="/register" element={<Register/>}/>
                    <Route path="/login" element={<Login/>}/>
                    <Route path="/chat" element={<ChatPage/>}/>
                    <Route path="/users" element={
                        <AdminRoute>
                            <UsersPage/>
                        </AdminRoute>
                    }/>
                </Routes>
            </div>
            </Router>
    );
}

export default App;
