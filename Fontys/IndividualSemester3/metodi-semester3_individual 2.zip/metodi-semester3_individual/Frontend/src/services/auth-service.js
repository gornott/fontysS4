import axios from "axios";
import http from '../http-common'
import jwt from 'jwt-decode'


class AuthService {
    login(email, password) {

        return axios
            .post(http.defaults.baseURL + "/login", {
                username: email,
                password
            })
            .then(response => {
                if (response.data.accessToken) {
                    localStorage.setItem("token", response.data.accessToken);
                    console.log(response.data.accessToken)
                }
                return response.data;
            });
    }

    logout() {
        localStorage.clear("token");
    }

    register(values) {

        return axios.post(http.defaults.baseURL + "/users", {
            email: values.email,
            password: values.password,
            firstName: values.firstName,
            lastName: values.lastName,
            weight: values.weight,
            height: values.height,
            age:values.age,
            gender:values.gender
        });
    }

    getCurrentUser() {
        return localStorage.getItem("token");
    }
    isLoggedIn(){
        if(localStorage.getItem("token") != null){
            try{
                const user = jwt(localStorage.getItem("token"))
                if(user.exp < Date.now() / 1000){
                    localStorage.clear("token")
                    return false
                }
                return true
            }
            catch{
                return false
            }
        }
        return false
    }
    isAdmin(){
        if(localStorage.getItem("token") != null){
            const user = jwt(localStorage.getItem("token"))
            return user.roles.includes("ADMIN")
        }
        return false;
    }
    areYouAdmin(){
        if(localStorage.getItem("token") != null) {

            const user = jwt(localStorage.getItem("token"))
            return !!user.roles.includes("ADMIN");

        }
        return false
    }


    getUserId(){
        if(localStorage.getItem("token") != null){
            const user = jwt(localStorage.getItem("token"))
            return user.userId
        }
        return null;
    }
}

export default new AuthService();