import axios from 'axios';
import authHeader from './auth-header';


const API_URL = 'http://localhost:8080/users';

class UserService {
    getUserBoard() {
        return axios.get(API_URL + 'USER', { headers: authHeader() });
    }

    getModeratorBoard() {
        return axios.get(API_URL + 'mod', { headers: authHeader() });
    }

    getAdminBoard() {
        return axios.get(API_URL + 'ADMIN', { headers: authHeader() });
    }
}

export default new UserService();