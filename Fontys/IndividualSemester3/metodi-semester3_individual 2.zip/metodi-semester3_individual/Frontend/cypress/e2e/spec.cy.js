describe('template spec', () => {
  it('shouldLogIn', () => {
    cy.visit('http://localhost:3000/')
    cy.get('#\\:r0\\:').type('metodi@gmail.com')
    cy.get('#\\:r1\\:').type('1234')
    cy.get('#\\:r2\\:').click()
    cy.url().should('include', '/diary/8');
  })
  it('shouldSearchMeal', () => {
    cy.viewport('macbook-15')
    cy.visit('http://localhost:3000/')
    cy.get('#\\:r0\\:').type('metodi@gmail.com')
    cy.get('#\\:r1\\:').type('1234')
    cy.get('#\\:r2\\:').click()
    cy.url().should('include', '/diary/8');
    cy.get(':nth-child(1) > .MuiFormControl-root > .MuiInputBase-root > #controllable-states-demo').type('chicken')
    cy.get('.css-1mg661y-MuiStack-root > :nth-child(2) > :nth-child(1)').click()
    cy.get(':nth-child(1) > .MuiFormControl-root > .MuiInputBase-root > #controllable-states-demo').click()
    cy.get('#controllable-states-demo-option-2').click()
    cy.get('.css-1mg661y-MuiStack-root > :nth-child(2) > :nth-child(2)').click()
    cy.get('.MuiTable-root').should('contain', 'Baked Chicken')
  })
})
