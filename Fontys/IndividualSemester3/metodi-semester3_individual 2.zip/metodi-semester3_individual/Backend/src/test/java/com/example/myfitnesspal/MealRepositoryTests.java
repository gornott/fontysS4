package com.example.myfitnesspal;

import com.example.myfitnesspal.domain.Meal;
import com.example.myfitnesspal.domain.Nutrient;
import com.example.myfitnesspal.repository.AccountEntity;
import com.example.myfitnesspal.repository.MealEntity;
import com.example.myfitnesspal.repository.MealRepository;
import com.example.myfitnesspal.repository.NutritionEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class MealRepositoryTests {
    @Autowired
    private MealRepository mealRepository;
    @Autowired
    EntityManager entityManager;
    MealEntity meal;
    AccountEntity account;

    @BeforeEach
    void setUp() {
        account = AccountEntity.builder()
                .id(8L)
                .email("test")
                .build();
        meal = MealEntity.builder()
                .id(1L)
                .name("Meal1")
                .calories(1000f)
                .totalNutrients(List.of(
                        NutritionEntity.builder()
                                .id(1L)
                                .label("Protein")
                                .quantity(100.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .id(2L)
                                .label("Carbs")
                                .quantity(100.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .id(3L)
                                .label("Fat")
                                .quantity(100.0)
                                .unit("g")
                                .build()
                ))
                .account(account)
                .build();
    }

    @Test
    void testSaveMeal() {
        MealEntity savedMeal = mealRepository.save(meal);
        assert savedMeal.getId() != null;
    }

    @Test
    void getMealById_ShouldReturnMeal() {
        MealEntity savedMeal = mealRepository.save(meal);
        MealEntity foundMeal = mealRepository.findById(savedMeal.getId()).get();
        assertEquals(savedMeal, foundMeal);
    }

    @Test
    void deleteMealById_ShouldDeleteMeal() {
        MealEntity savedMeal = mealRepository.save(meal);
        mealRepository.deleteById(savedMeal.getId());
        Optional<MealEntity> foundMeal = mealRepository.findById(savedMeal.getId());
        assertEquals(Optional.empty(), foundMeal);
    }
}
