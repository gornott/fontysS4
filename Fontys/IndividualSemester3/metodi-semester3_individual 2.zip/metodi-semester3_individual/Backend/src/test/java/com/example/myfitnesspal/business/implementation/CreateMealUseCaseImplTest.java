package com.example.myfitnesspal.business.implementation;
import com.example.myfitnesspal.business.CreateUserUseCase;
import com.example.myfitnesspal.domain.CreateMealRequest;
import com.example.myfitnesspal.domain.CreateMealResponse;
import com.example.myfitnesspal.repository.MealEntity;
import com.example.myfitnesspal.repository.MealRepository;
import com.example.myfitnesspal.repository.NutritionEntity;
import com.example.myfitnesspal.repository.NutritionRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class CreateMealUseCaseImplTest {
    @Mock
    private MealRepository mealRepository;
    @Mock
    private NutritionRepository nutritionRepository;
    @InjectMocks
    private CreateMealUseCaseImpl createMealUseCase;
    @Test
    void createMeal_shouldCreateMeal() {
        CreateMealRequest request = CreateMealRequest.builder()
                .name("Meal1")
                .calories(100F)
                .totalNutrients(List.of(
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Protein")
                                .quantity(10.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Carbs")
                                .quantity(20.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Fat")
                                .quantity(30.0)
                                .unit("g")
                                .build()
                ).stream().map(NutrientConverter::convertNut).toList())
                .build();
        MealEntity mealEntity = MealEntity.builder()
                .name("Meal1")
                .calories(100F)
                .totalNutrients(List.of(
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Protein")
                                .quantity(10.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Carbs")
                                .quantity(20.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Fat")
                                .quantity(30.0)
                                .unit("g")
                                .build()
                ))
                .build();

        when(mealRepository.save(any(MealEntity.class)))
                        .thenAnswer(invocation -> invocation.getArgument(0));
        when(nutritionRepository.saveAll(anyList()))
                .thenReturn(mealEntity.getTotalNutrients());
        CreateMealUseCaseImpl createMealUseCase = new CreateMealUseCaseImpl(mealRepository,nutritionRepository);
        CreateMealResponse response = createMealUseCase.createMeal(request);
        CreateMealResponse expectedResponse = CreateMealResponse.builder()
                .name("Meal1")
                .calories(100F)
                .totalNutrients(List.of(
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Protein")
                                .quantity(10.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Carbs")
                                .quantity(20.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Fat")
                                .quantity(30.0)
                                .unit("g")
                                .build()
                ).stream().map(NutrientConverter::convertNut).toList())
                .build();
        assertEquals(expectedResponse, response);
        verify(mealRepository).save(any(MealEntity.class));
    }
}
