package com.example.myfitnesspal.business.implementation;
import com.example.myfitnesspal.business.exeption.InvalidUserExeption;
import com.example.myfitnesspal.domain.Account;
import com.example.myfitnesspal.domain.UpdateUserRequest;
import com.example.myfitnesspal.repository.AccountEntity;
import com.example.myfitnesspal.repository.AccountRepository;
import com.example.myfitnesspal.repository.UserEntity;
import com.example.myfitnesspal.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UpdateUserUseCaseImplTest {
    @Mock
    private UserRepository userRepository;
    @Mock
    private AccountRepository accountRepository;
    @InjectMocks
    private UpdateUserUseCaseImlp updateUserUseCase;
    AccountEntity accountEntity;
    UserEntity userEntity;


    @BeforeEach
    void setUp() {
        accountEntity = AccountEntity.builder()
                .id(1L)
                .email("username@gmail.com")
                .FirstName("firstname")
                .LastName("lastname")
                .Age(20)
                .Weight(80L)
                .Height(180L)
                .Gender("Male")
                .build();
        userEntity = UserEntity.builder()
                .id(1L)
                .username("user@gmail.com")
                .password("912y3ciuhkj123huu8oijlkrwu8eoijlk")
                .account(accountEntity)
                .build();
    }

    @Test
    void shouldUpdateUser() {
        UpdateUserRequest request = UpdateUserRequest.builder()
                .id(1L)
                .password("password1")
                .email("username1")
                .firstName("firstname")
                .lastName("lastname")
                .age(20)
                .weight(80L)
                .height(188L)
                .gender("Female")
                .build();
        when(userRepository.findById(1L)).thenReturn(Optional.of(userEntity));
        when(accountRepository.findById(1L)).thenReturn(Optional.of(accountEntity));
        updateUserUseCase.updateUser(request);
        verify(accountRepository).save(any(AccountEntity.class));
    }

    @Test
    void shouldThrowExceptionWhenUpdatingUser() {
        UpdateUserRequest request = UpdateUserRequest.builder()
                .id(0L)
                .password("password")
                .email("username")
                .firstName("firstname")
                .lastName("lastname")
                .age(20)
                .weight(80L)
                .height(180L)
                .gender("Female")
                .build();
        when(accountRepository.findById(0L)).thenReturn(Optional.empty());
        assertThrows(InvalidUserExeption.class, () -> updateUserUseCase.updateUser(request));
    }

    @Test
    void shouldThrowExceptionWhenUpdatingUserWithNullId() {
        UpdateUserRequest request = UpdateUserRequest.builder()
                .id(null)
                .password("password")
                .email("username")
                .firstName("firstname")
                .lastName("lastname")
                .age(20)
                .weight(80L)
                .height(180L)
                .gender("test")
                .build();
        assertThrows(InvalidUserExeption.class, () -> updateUserUseCase.updateUser(request));
    }
    @Test
    void updateEmail(){
        when(userRepository.findById(1L)).thenReturn(Optional.of(userEntity));
        when(accountRepository.findById(1L)).thenReturn(Optional.of(accountEntity));
        UpdateUserRequest request = UpdateUserRequest.builder()
                .id(1L)
                .email("username1@gmail.com")
                .build();
        updateUserUseCase.updateUser(request);
    }

    @Test
    void shouldUpdatePassword() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(userEntity));
        when(accountRepository.findById(1L)).thenReturn(Optional.of(accountEntity));
        UpdateUserRequest request = UpdateUserRequest.builder()
                .id(1L)
                .password("password1")
                .build();
        updateUserUseCase.updateUser(request);
    }
}


