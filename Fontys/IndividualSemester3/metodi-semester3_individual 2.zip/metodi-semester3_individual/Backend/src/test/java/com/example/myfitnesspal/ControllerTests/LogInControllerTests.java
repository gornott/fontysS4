package com.example.myfitnesspal.ControllerTests;

import com.example.myfitnesspal.business.LoginUseCase;
import com.example.myfitnesspal.business.implementation.AccountConverter;
import com.example.myfitnesspal.domain.Account;
import com.example.myfitnesspal.domain.LoginRequest;
import com.example.myfitnesspal.repository.UserEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class LogInControllerTests {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private LoginUseCase loginUseCase;
    @MockBean
    private PasswordEncoder passwordEncoder;
    UserEntity userEntity;

    @BeforeEach
    public void setUp() {
        userEntity = UserEntity.builder()
                .id(1L)
                .username("user@gmail.com")
                .password(passwordEncoder.encode("password"))
                .build();
    }

    @Test
    public void testLogin() throws Exception {
        LoginRequest loginRequest = LoginRequest.builder()
                .username("user@gmail.com")
                .password("password")
                .build();
        mockMvc.perform(post("/login").contentType("application/json")
                        .content("""
                                {
                                "username": "user@gmail.com",
                                "password": "password"
                                }
                                """))
                .andExpect(status().isOk());
        verify(loginUseCase).login(loginRequest);
    }
}
