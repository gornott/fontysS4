package com.example.myfitnesspal;

import com.example.myfitnesspal.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.persistence.EntityManager;
import java.util.List;
import java.util.Set;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class AccountRepositoryTests {
    @Autowired
    private AccountRepository accountRepository;
    @Mock
    private PasswordEncoder passwordEncoder;
    @Autowired
    private EntityManager entityManager;
    MealEntity meal;
    UserEntity user;

    @BeforeEach
    void setUp() {
        user = UserEntity.builder()
                .id(1L)
                .username("test")
                .password(passwordEncoder.encode("test"))
                .userRoles(Set.of(UserRoleEntity.builder()
                        .id(1L)
                        .role(RoleEnum.USER)
                        .build()))
                .account(AccountEntity.builder()
                        .email("test")
                        .FirstName("test")
                        .LastName("test")
                        .Age(20)
                        .Height(180L)
                        .Weight(80L)
                        .Gender("test")
                        .build())
                .build();
        meal = MealEntity.builder()
                .id(1L)
                .name("Meal1")
                .calories(1000f)
                .totalNutrients(List.of(
                        NutritionEntity.builder()
                                .id(1L)
                                .label("Protein")
                                .quantity(100.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .id(2L)
                                .label("Carbs")
                                .quantity(100.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .id(3L)
                                .label("Fat")
                                .quantity(100.0)
                                .unit("g")
                                .build()
                ))
                .account(user.getAccount())
                .build();
    }

    @Test
    void saveUser_shouldSaveUser() {
        AccountEntity saved = accountRepository.save(user.getAccount());
        saved = entityManager.find(AccountEntity.class, saved.getId());
        AccountEntity expected = user.getAccount();
        assertEquals(expected, saved);
    }
    @Test
    void getUsers_shouldReturnAllUsers() {
        accountRepository.save(user.getAccount());
        List<AccountEntity> users = accountRepository.findAll();
        assertNotNull(users);
    }
    @Test
    void getUserById_shouldReturnUser() {
        AccountEntity saved = accountRepository.save(user.getAccount());
        AccountEntity expected = entityManager.find(AccountEntity.class, saved.getId());
        assertEquals(expected, saved);
    }
    @Test
    void deleteUserById_shouldDeleteUser() {
        AccountEntity saved = accountRepository.save(user.getAccount());
        accountRepository.deleteById(saved.getId());
        AccountEntity expected = entityManager.find(AccountEntity.class, saved.getId());
        assertNull(expected);
    }
    @Test
    void updateUser_shouldUpdateUser() {
        AccountEntity saved = accountRepository.save(user.getAccount());
        saved.setFirstName("test2");
        accountRepository.save(saved);
        AccountEntity expected = entityManager.find(AccountEntity.class, saved.getId());
        assertEquals(expected, saved);
    }
}
