package com.example.myfitnesspal.business;


import com.example.myfitnesspal.domain.LoginRequest;
import com.example.myfitnesspal.domain.LoginResponse;

public interface LoginUseCase {
    LoginResponse login(LoginRequest loginRequest);
}
