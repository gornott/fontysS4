package com.example.myfitnesspal.business;

import com.example.myfitnesspal.domain.CreateMealRequest;
import com.example.myfitnesspal.domain.CreateMealResponse;

import javax.transaction.Transactional;

public interface CreateMealUseCase {
    CreateMealResponse createMeal(CreateMealRequest request);
}
