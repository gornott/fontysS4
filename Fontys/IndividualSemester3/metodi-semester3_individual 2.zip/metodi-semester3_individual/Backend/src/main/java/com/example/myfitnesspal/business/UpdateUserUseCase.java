package com.example.myfitnesspal.business;

import com.example.myfitnesspal.domain.UpdateUserRequest;

public interface UpdateUserUseCase {
    void updateUser(UpdateUserRequest request);
}
