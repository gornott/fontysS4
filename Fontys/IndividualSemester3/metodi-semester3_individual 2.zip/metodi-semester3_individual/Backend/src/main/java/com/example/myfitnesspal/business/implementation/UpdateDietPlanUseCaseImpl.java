package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.business.UpdateDietPlanUseCase;
import com.example.myfitnesspal.business.exeption.NotFoundExeption;
import com.example.myfitnesspal.domain.UpdateDietPlanRequest;
import com.example.myfitnesspal.repository.DietPlanEntity;
import com.example.myfitnesspal.repository.DietPlanRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;


@Service
@AllArgsConstructor
public class UpdateDietPlanUseCaseImpl implements UpdateDietPlanUseCase {
    private final DietPlanRepository dietPlanRepository;

    public void updateFields(UpdateDietPlanRequest request, DietPlanEntity diet) {
        diet.setCode(request.getCode());
        diet.setName(request.getName());
        dietPlanRepository.save(diet);
    }

    @Override
    public void updateDietPlan(UpdateDietPlanRequest request) {
        Optional<DietPlanEntity> diet = dietPlanRepository.findById(request.getDietPlanId());
        if (diet.isPresent()) {
            updateFields(request, diet.get());
        } else {
            throw new NotFoundExeption("DIET_PLAN_NOT_FOUND");
        }
    }
}

