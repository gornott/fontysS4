package com.example.myfitnesspal.business;

import com.example.myfitnesspal.domain.UpdateDietPlanRequest;

public interface UpdateDietPlanUseCase {
    void updateDietPlan(UpdateDietPlanRequest request);
}

