package com.example.myfitnesspal.business.implementation;
import com.example.myfitnesspal.business.CreateMealUseCase;
import com.example.myfitnesspal.domain.CreateMealRequest;
import com.example.myfitnesspal.domain.CreateMealResponse;
import com.example.myfitnesspal.domain.Nutrient;
import com.example.myfitnesspal.repository.*;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.stream.Collectors;


@Service
@AllArgsConstructor
public class CreateMealUseCaseImpl implements CreateMealUseCase {

    private final MealRepository mealRepository;
    private final NutritionRepository nutritionRepository;

    @Transactional
    @Override
    public CreateMealResponse createMeal(CreateMealRequest request) {
        AccountEntity accountEntity = AccountEntity.builder()
                .id(request.getUser_id())
                .build();
        MealEntity newMeal = MealEntity.builder()
                .name(request.getName())
                .calories(request.getCalories())
                .totalNutrients(request.getTotalNutrients().stream().map( nutrient -> {
                    NutritionEntity nutritionEntity = NutritionEntity.builder()
                            .id(nutrient.getId())
                            .meal(nutrient.getMealId())
                            .label(nutrient.getLabel())
                            .quantity(nutrient.getQuantity())
                            .unit(nutrient.getUnit())
                            .build();
                    return nutritionEntity;
                }).collect(Collectors.toList()))
                .account(accountEntity)
                .build();
        MealEntity savedMeal = save(newMeal);
        nutritionRepository.saveAll(savedMeal.getTotalNutrients());




        return CreateMealResponse.builder()
                .id(savedMeal.getId())
                .name(savedMeal.getName())
                .calories(savedMeal.getCalories())
                .totalNutrients(savedMeal.getTotalNutrients().stream().map(NutrientConverter::convertNut).toList())
                .user_id(savedMeal.getAccount().getId())
                .build();
    }

    private MealEntity save(MealEntity meal) {
        return mealRepository.save(meal);
    }
}

