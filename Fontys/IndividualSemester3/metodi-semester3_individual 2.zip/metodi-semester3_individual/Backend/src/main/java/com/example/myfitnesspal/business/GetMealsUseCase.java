package com.example.myfitnesspal.business;

import com.example.myfitnesspal.domain.GetMealsResponse;

public interface GetMealsUseCase {
    GetMealsResponse getMeals(Long id, String order);
}
