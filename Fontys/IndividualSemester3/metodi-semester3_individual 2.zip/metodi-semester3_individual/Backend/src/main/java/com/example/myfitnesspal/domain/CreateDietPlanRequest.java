package com.example.myfitnesspal.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;
import javax.validation.constraints.NotBlank;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateDietPlanRequest {
    @NotBlank

    private String code;

    @NotBlank
    @Length(min = 2)
    private String name;
}