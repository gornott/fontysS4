package com.example.myfitnesspal.business;

public interface DeleteDietPlanUseCase {
    void deleteDietPlan(Long id);
}
