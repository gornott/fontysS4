package com.example.myfitnesspal.controller;

import com.example.myfitnesspal.business.CreateDietPlanUseCase;
import com.example.myfitnesspal.business.DeleteDietPlanUseCase;
import com.example.myfitnesspal.business.GetDietPlansUseCase;
import com.example.myfitnesspal.business.UpdateDietPlanUseCase;
import com.example.myfitnesspal.domain.CreateDietPlanRequest;
import com.example.myfitnesspal.domain.CreateDietPlanResponse;
import com.example.myfitnesspal.domain.GetDietPlansResponse;
import com.example.myfitnesspal.domain.UpdateDietPlanRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;

import javax.validation.Valid;
import java.util.Arrays;
import java.util.Collections;

@RestController
@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
@RequestMapping("/plans")
@RequiredArgsConstructor
public class DietPlansController {
    private final GetDietPlansUseCase getDietPlansUseCase;
    private final CreateDietPlanUseCase createDietPlanUseCase;
    private final DeleteDietPlanUseCase deleteDietPlanUseCase;

    private final UpdateDietPlanUseCase updateDietPlanUseCase;

    final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    final CorsConfiguration config = new CorsConfiguration();


    @GetMapping
    public ResponseEntity<GetDietPlansResponse> getDietPlans() {
        return ResponseEntity.ok(getDietPlansUseCase.getDietPlans());
    }

    @PostMapping
    public ResponseEntity<CreateDietPlanResponse> createDietPlan(
            @RequestBody @Valid CreateDietPlanRequest createDietPlanRequest) {
        CreateDietPlanResponse response = createDietPlanUseCase.createDietPlan(createDietPlanRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
    @DeleteMapping("/{id}")
    @ResponseBody
    public ResponseEntity<Void> deleteDietPlan(@PathVariable Long id) {
        deleteDietPlanUseCase.deleteDietPlan(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> updateDietPlan(
            @PathVariable("id") Long id,
            @RequestBody @Valid UpdateDietPlanRequest updateDietPlanRequest) {
        updateDietPlanRequest.setDietPlanId(id);
        updateDietPlanUseCase.updateDietPlan(updateDietPlanRequest);
        return ResponseEntity.noContent().build();
    }
}