package com.example.myfitnesspal.controller;

import com.example.myfitnesspal.business.CreateUserUseCase;
import com.example.myfitnesspal.business.GetUsersUseCase;
import com.example.myfitnesspal.business.UpdateUserUseCase;
import com.example.myfitnesspal.config.security.isauthenticated.IsAuthenticated;
import com.example.myfitnesspal.domain.CreateUserRequest;
import com.example.myfitnesspal.domain.CreateUserResponce;
import com.example.myfitnesspal.domain.GetAllUsersResponse;
import com.example.myfitnesspal.domain.UpdateUserRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;

@RestController
@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*", exposedHeaders = "Authorization")
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController
{
 private final CreateUserUseCase createUserUseCase;
 private final GetUsersUseCase getAllUsersUseCase;
 private final UpdateUserUseCase updateUserUseCase;

 @PostMapping
   public ResponseEntity<CreateUserResponce> createUser(@RequestBody CreateUserRequest createUserRequest)
   {
    CreateUserResponce createUserResponce = createUserUseCase.createUser(createUserRequest);
    return ResponseEntity.ok(createUserResponce);
   }
   @IsAuthenticated
   @RolesAllowed("ROLE_ADMIN")
   @GetMapping
    public ResponseEntity<GetAllUsersResponse> getAllUsers()
    {
     return ResponseEntity.ok(getAllUsersUseCase.getUsers());
    }
    @IsAuthenticated
    @RolesAllowed("ROLE_ADMIN")
    @PutMapping
    public ResponseEntity<Void> updateUser(@RequestBody UpdateUserRequest updateUserRequest)
    {
     updateUserUseCase.updateUser(updateUserRequest);
     return ResponseEntity.noContent().build();
    }
}
