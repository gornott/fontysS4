package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.domain.Account;
import com.example.myfitnesspal.repository.AccountEntity;

public class AccountConverter {
    public static Account convert(AccountEntity account) {
        return Account.builder()
                .id(account.getId())
                .Email(account.getEmail())
                .Age(account.getAge())
                .FirstName(account.getFirstName())
                .LastName(account.getLastName())
                .Gender(account.getGender())
                .Height(account.getHeight())
                .Weight(account.getWeight())
                .build();
    }
}