package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.business.GetUsersUseCase;
import com.example.myfitnesspal.domain.GetAllUsersResponse;
import com.example.myfitnesspal.repository.AccountRepository;
import com.example.myfitnesspal.repository.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class GetUsersUseCaseImpl implements GetUsersUseCase {
    private final AccountRepository AccountRepository;

    @Override
    public GetAllUsersResponse getUsers() {
        return GetAllUsersResponse.builder()
                .accounts(AccountRepository.findAll()
                        .stream()
                        .map(AccountConverter::convert)
                        .toList())
                .build();
    }
}

