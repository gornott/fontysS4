package com.example.myfitnesspal.business.exeption;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class InvalidDietPlanException extends ResponseStatusException {
    public InvalidDietPlanException() {
        super(HttpStatus.BAD_REQUEST, "DIET_INVALID");
    }

    public InvalidDietPlanException(String errorCode) {
        super(HttpStatus.BAD_REQUEST, errorCode);
    }
}