package com.example.myfitnesspal.domain;

import com.example.myfitnesspal.repository.RoleEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Account {
    private Long id;
    private String FirstName;
    private String LastName;
    private String Email;
    private Long Weight;
    private Long Height;
    private Integer Age;
    private String Gender;
}

