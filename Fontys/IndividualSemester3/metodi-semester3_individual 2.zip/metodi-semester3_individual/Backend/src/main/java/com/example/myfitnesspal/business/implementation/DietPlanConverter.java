package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.domain.DietPlan;
import com.example.myfitnesspal.repository.DietPlanEntity;

final class DietPlanConverter {
    private DietPlanConverter() {
    }

    public static DietPlan convert(DietPlanEntity dietPlanEntity) {
        return DietPlan.builder()
                .id(dietPlanEntity.getId())
                .code(dietPlanEntity.getCode())
                .name(dietPlanEntity.getName())
                .build();
    }
}