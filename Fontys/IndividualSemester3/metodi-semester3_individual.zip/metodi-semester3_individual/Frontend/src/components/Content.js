import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import SearchIcon from '@mui/icons-material/Search';
import Stack from '@mui/material/Stack';
import Chart from "react-apexcharts";
import Table from "./NutritionTable"
import axios from "axios";
import 'semantic-ui-css/semantic.min.css'
import Autocomplete from '@mui/material/Autocomplete';
import ButtonGroup from '@mui/material/ButtonGroup';
import SendIcon from '@mui/icons-material/Send';
import xtype from "xtypejs";




export default function Content(props) {
    const [search, setSearch] = React.useState("");
    const [data, setData] = React.useState([]);
    const [selected, setSelected] = React.useState(data);
    let totalProtein =parseFloat(props.diets.map(
        (post) => post.totalNutrients.at(2).quantity).reduce((a, b) => a + b, 1).toFixed(1));
    let totalFat =parseFloat( props.diets.map(
        (post) => post.totalNutrients.at(0).quantity).reduce((a, b) => a + b, 1).toFixed(1));
    let totalCarbs = parseFloat(props.diets.map(
        (post) => post.totalNutrients.at(1).quantity).reduce((a, b) => a + b, 1).toFixed(1));
    console.log(xtype(totalProtein))
        function handleOnSearch () {
            axios.get('https://api.edamam.com/api/recipes/v2', {
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE,PATCH,OPTIONS',
                },
                params:
                    {q: search, app_id: "74c08f1f", app_key: "25bc6292fcf73a7bff491ec99c75e554", type: "public"}
            })
                .then((response) => {
                    setData(response.data.hits);
                    console.log(response.data.hits)
                })
                .catch((error) => {
                    console.log(error);
                })
        }

            const handleSubmit = e => {
                props.onAdd(selected)
            }

            return (

                <Paper sx={{maxWidth: 936, margin: 'auto', overflow: 'hidden'}}>
                    <AppBar
                        position="static"
                        color="default"
                        elevation={0}
                        sx={{borderBottom: '1px solid rgba(1, 0, 2, 0.12)'}}
                    >

                        <Grid container spacing={2} height={400} alignItems="center">
                            <Chart type={"donut"} width={450} height={400} series={[totalProtein, totalFat, totalCarbs]} options={{
                                labels: ['Proteins', 'Fats', 'Carbs']
                            }}/>
                            <Grid>
                                <Stack spacing={2} sx={{width: 400}}>
                                    <Autocomplete
                                        onChange={(event, newValue) => {
                                            setSelected(newValue)
                                            console.log(newValue)
                                        }}
                                        freeSolo
                                        id="controllable-states-demo"
                                        size="small"
                                        options={data.map((option) => option.recipe)}
                                        getOptionLabel={(option) => {
                                            if (option.label === undefined) {
                                                return ""
                                            }
                                            return `${option.label}   (${Math.round(option.calories)}cal)`

                                        }}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                variant="standard"
                                                label="Breakfast"
                                                placeholder="Add Breakfast"
                                                value={search}
                                                onChange={(e) => setSearch(e.target.value)}
                                            />

                                        )}
                                    />
                                    <ButtonGroup disableElevation variant="contained"
                                                 aria-label="Disabled elevation buttons">
                                        <Button variant="contained" endIcon={<SearchIcon/>} onClick={handleOnSearch}>Search
                                            Breakfast</Button>
                                        <Button variant="contained" endIcon={<SendIcon/>} onClick={handleSubmit}>Add
                                            Breakfast</Button>
                                    </ButtonGroup>

                                    <Autocomplete
                                        value={""}
                                        onChange={(event, newValue) => {
                                            setSelected(newValue)
                                            console.log(newValue)
                                        }}
                                        freeSolo
                                        id="controllable-states-demo"
                                        size="small"
                                        options={data.map((option) => option.recipe)}
                                        getOptionLabel={(option) => {
                                            if (option.label === undefined) {
                                                return ""
                                            }
                                            return `${option.label}   (${Math.round(option.calories)}cal)`

                                        }}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                variant="standard"
                                                label="Lunch"
                                                placeholder="Add Lunch"
                                                value={search}
                                                onChange={(e) => setSearch(e.target.value)}
                                            />

                                        )}
                                    />
                                    <ButtonGroup disableElevation variant="contained"
                                                 aria-label="Disabled elevation buttons">
                                        <Button variant="contained" endIcon={<SearchIcon/>} onClick={handleOnSearch}>Search
                                            Lunch</Button>
                                        <Button variant="contained" endIcon={<SendIcon/>} onClick={handleSubmit}>Add
                                            Lunch</Button>
                                    </ButtonGroup>
                                    <Autocomplete
                                        onChange={(event, newValue) => {
                                            setSelected(newValue)
                                            console.log(newValue)
                                        }}
                                        freeSolo
                                        id="controllable-states-demo"
                                        size="small"
                                        options={data.map((option) => option.recipe)}
                                        getOptionLabel={(option) => {
                                            if (option.label === undefined) {
                                                return ""
                                            }
                                            return `${option.label}   (${Math.round(option.calories)}cal)`

                                        }}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                                variant="standard"
                                                label="Dinner"
                                                placeholder="Add Dinner"
                                                value={search}
                                                onChange={(e) => setSearch(e.target.value)}
                                            />

                                        )}
                                    />
                                    <ButtonGroup disableElevation variant="contained"
                                                 aria-label="Disabled elevation buttons">
                                        <Button variant="contained" endIcon={<SearchIcon/>} onClick={handleOnSearch}>Search
                                            Diner</Button>
                                        <Button variant="contained" endIcon={<SendIcon/>} onClick={handleSubmit}>Add
                                            Diner</Button>
                                    </ButtonGroup>
                                </Stack>
                            </Grid>
                        </Grid>
                        <Table diets={props.diets} totalP={totalProtein} totalF={totalFat} totalC={totalCarbs}
                               onRemove={props.OnRemove} filter={props.filter} handleChange={props.handleChange}/>
                    </AppBar>


                    <AppBar
                        position="static"
                        color="default"
                        elevation={0}
                        sx={{borderBottom: '1px solid rgba(0, 0, 0, 0.12)'}}
                    >

                    </AppBar>
                    <Typography sx={{my: 5, mx: 2}} color="text.secondary" align="center">
                        No users for this project yet
                    </Typography>
                </Paper>
            );
    }