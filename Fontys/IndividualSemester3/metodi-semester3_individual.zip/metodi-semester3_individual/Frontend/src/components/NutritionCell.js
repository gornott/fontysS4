import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import Button from '@mui/material/Button';
import ButtonGroup from '@mui/material/ButtonGroup';
import Box from "@mui/material/Box";
import axios from "axios";
import http from '../http-common'



export default function Cell(props){
    const handleRemove = e => {
        props.onRemove(props.diet.id)
        document.querySelector('#delete-request .status');
        console.log(props.diet.id);
        axios.delete(http.defaults.baseURL+'/diary/'+ props.diet.id )
            .then(response => console.log(response))
    }
return(

            <TableRow
                key={props.diet.name}
                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
                <TableCell component="th" scope="row">
                    {props.diet.name}

                </TableCell>
                <TableCell align="right">{props.diet.calories.toFixed()}</TableCell>
                <TableCell align="right">{(props.diet.totalNutrients.at(0).quantity).toFixed(1)}</TableCell>
                <TableCell align="right">{(props.diet.totalNutrients.at(1).quantity).toFixed(1)}</TableCell>
                <TableCell align="right">{(props.diet.totalNutrients.at(2).quantity).toFixed(1)}</TableCell>
                <TableCell align="right" component="th" scope="row">
                    <Box
                        sx={{
                            display: 'flex',
                            '& > *': {
                                m: 1,
                            },
                        }}
                    >
                        <ButtonGroup
                            aling="left"
                            orientation="vertical"
                            aria-label="vertical contained button group"
                            variant="contained"
                        >
                            <Button key="one" color="error" onClick={handleRemove}>Delete</Button>
                        </ButtonGroup>
                    </Box>

                </TableCell>

            </TableRow>
)
}