import {Route, Navigate} from 'react-router-dom';

import auth from '../../services/auth-service';

function AdminRoute({children}){
    if(auth.isAdmin() && auth.isLoggedIn()){
        return children;
    }
    return <Navigate to="/login" />
}
export default AdminRoute;