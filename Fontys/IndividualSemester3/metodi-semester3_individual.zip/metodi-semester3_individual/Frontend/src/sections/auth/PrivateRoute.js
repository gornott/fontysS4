import {Route, Navigate} from 'react-router-dom';

import auth from '../../services/auth-service';


function PrivateRoute({children}) {

    if (!auth.isLoggedIn()) {
        // not logged in so redirect to login page with the return url
        return <Navigate to="/login"/>
    }
    // authorized so return component
    return children
}

export default PrivateRoute