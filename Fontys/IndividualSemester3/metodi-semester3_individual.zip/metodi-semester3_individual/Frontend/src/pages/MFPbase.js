import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Navigator from '../components/Navigator';
import Content from '../components/Content';
import Header from '../components/Header';
import axios from "axios";
import {useEffect, useState} from "react";
import httpCommon from "../http-common";
import xtype from "xtypejs";
import authService from "../services/auth-service";
import Filter from "../components/SelectFilter";


let theme = createTheme({
    palette: {
        primary: {
            light: '#63ccff',
            main: '#009be5',
            dark: '#006db3',
        },
    },
    typography: {
        h5: {
            fontWeight: 500,
            fontSize: 26,
            letterSpacing: 0.5,
        },
    },
    shape: {
        borderRadius: 8,
    },
    components: {
        MuiTab: {
            defaultProps: {
                disableRipple: true,
            },
        },
    },
    mixins: {
        toolbar: {
            minHeight: 48,
        },
    },
});

theme = {
    ...theme,
    components: {
        MuiDrawer: {
            styleOverrides: {
                paper: {
                    backgroundColor: '#081627',
                },
            },
        },
        MuiButton: {
            styleOverrides: {
                root: {
                    textTransform: 'none',
                },
                contained: {
                    boxShadow: 'none',
                    '&:active': {
                        boxShadow: 'none',
                    },
                },
            },
        },
        MuiTabs: {
            styleOverrides: {
                root: {
                    marginLeft: theme.spacing(1),
                },
                indicator: {
                    height: 3,
                    borderTopLeftRadius: 3,
                    borderTopRightRadius: 3,
                    backgroundColor: theme.palette.common.white,
                },
            },
        },
        MuiTab: {
            styleOverrides: {
                root: {
                    textTransform: 'none',
                    margin: '0 16px',
                    minWidth: 0,
                    padding: 0,
                    [theme.breakpoints.up('md')]: {
                        padding: 0,
                        minWidth: 0,
                    },
                },
            },
        },
        MuiIconButton: {
            styleOverrides: {
                root: {
                    padding: theme.spacing(1),
                },
            },
        },
        MuiTooltip: {
            styleOverrides: {
                tooltip: {
                    borderRadius: 4,
                },
            },
        },
        MuiDivider: {
            styleOverrides: {
                root: {
                    backgroundColor: 'rgb(255,255,255,0.15)',
                },
            },
        },
        MuiListItemButton: {
            styleOverrides: {
                root: {
                    '&.Mui-selected': {
                        color: '#4fc3f7',
                    },
                },
            },
        },
        MuiListItemText: {
            styleOverrides: {
                primary: {
                    fontSize: 14,
                    fontWeight: theme.typography.fontWeightMedium,
                },
            },
        },
        MuiListItemIcon: {
            styleOverrides: {
                root: {
                    color: 'inherit',
                    minWidth: 'auto',
                    marginRight: theme.spacing(2),
                    '& svg': {
                        fontSize: 20,
                    },
                },
            },
        },
        MuiAvatar: {
            styleOverrides: {
                root: {
                    width: 32,
                    height: 32,
                },
            },
        },
    },
};

const drawerWidth = 256;

export default function Paperbase() {
    const [diets, setDiet] = useState([]);
    const [user] = useState(authService.getUserId());

    // eslint-disable-next-line no-unused-vars
    let protein= {}
    // eslint-disable-next-line no-unused-vars
    let fat = {}
    // eslint-disable-next-line no-unused-vars
    let carbs = {}
    const [filter, setFilter] = React.useState("");

    const handleChange = (event) => {
        setFilter(event.target.value);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    async function getDiets() {
        if(filter===""){
            const response = await axios.get(httpCommon.defaults.baseURL
                +`/diary/${user}/all`);
            setDiet(response.data.meals);
        }
        else {
            const response = await axios.get(httpCommon.defaults.baseURL
            +`/diary/${user}/${filter}`);
            setDiet(response.data.meals);
        }
    }
    useEffect(() => {
        getDiets().then(r=>console.log("done"));
    }, [filter]);

    const [mobileOpen, setMobileOpen] = React.useState(false);
    const isSmUp = useMediaQuery(theme.breakpoints.up('sm'));

    const handleDrawerToggle = () => {
        setMobileOpen(!mobileOpen);
    };
    const onRemove = e => {
        console.log("remove item with id: " + e);
        setDiet(diets.filter(todo => todo.id !== e));
    }
    const onAdd = selected => {
        const newMeal = {
            user_id: user,
            name: selected.label,
            calories: selected.calories,
            totalNutrients: [
                protein = {
                    label: "Protein",
                    quantity: selected.totalNutrients.PROCNT.quantity,
                    unit: "g"
                },
                fat = {
                    label: "Fat",
                    quantity: selected.totalNutrients.FAT.quantity,
                    unit: "g"
                },
                carbs ={
                    label: "Carbs",
                    quantity: selected.totalNutrients.CHOCDF.quantity,
                    unit: "g"
                }
            ]

        }

        console.log(newMeal);
        console.log(xtype(newMeal.totalNutrients));


        axios.post(httpCommon.defaults.baseURL + "/diary", newMeal)
            .then((response => setDiet([...diets, response.data])
            ))
            .catch((error) => {
                console.log(error);
            })
        console.log(user);
    }

    return (
        <ThemeProvider theme={theme}>
            <Box sx={{ display: 'flex', minHeight: '100vh' }}>
                <CssBaseline />
                <Box
                    component="nav"
                    sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
                >
                    {isSmUp ? null : (
                        <Navigator
                            PaperProps={{ style: { width: drawerWidth } }}
                            variant="temporary"
                            open={mobileOpen}
                            onClose={handleDrawerToggle}
                        />
                    )}

                    <Navigator
                        PaperProps={{ style: { width: drawerWidth } }}
                        sx={{ display: { sm: 'block', xs: 'none' } }}
                    />
                </Box>
                <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                    <Header tablabel={"Diary"} onDrawerToggle={handleDrawerToggle} />
                    <Box component="main" sx={{ flex: 1, py: 6, px: 4, bgcolor: '#eaeff1' }}>
                        <Content diets={diets} OnRemove={onRemove} onAdd={onAdd}
                                 filter={<Filter filter={filter}
                                                 handleChange={handleChange}/>}/>

                    </Box>
                    <Box component="footer" sx={{ p: 2, bgcolor: '#eaeff1' }}>

                    </Box>
                </Box>
            </Box>
        </ThemeProvider>
    );
}
