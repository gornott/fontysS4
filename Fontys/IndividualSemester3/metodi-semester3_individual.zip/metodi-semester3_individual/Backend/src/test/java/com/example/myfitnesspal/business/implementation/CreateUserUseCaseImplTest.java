package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.business.exeption.InvalidUserExeption;
import com.example.myfitnesspal.domain.Account;
import com.example.myfitnesspal.domain.CreateMealResponse;
import com.example.myfitnesspal.domain.CreateUserRequest;
import com.example.myfitnesspal.domain.CreateUserResponce;
import com.example.myfitnesspal.repository.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CreateUserUseCaseImplTest {
    @Mock
    private UserRepository userRepository;
    @Mock
    private AccountRepository accountRepository;
    @Mock
    private PasswordEncoder passwordEncoder;
    @InjectMocks
    private CreateUserUseCaseImpl createUserUseCase;

    private AccountEntity accountEntity;
    private UserEntity userEntity;
    private Account account;

    @BeforeEach
     void setUp() {
        accountEntity = AccountEntity.builder()
                .id(1L)
                .email("user1@gmail.com")
                .FirstName("user1")
                .LastName("user1")
                .Age(20)
                .Height(180L)
                .Gender("male")
                .Weight(80L)
                .meals(Set.of(
                        MealEntity.builder()
                                .id(1L)
                                .name("Meal1")
                                .build(),
                        MealEntity.builder()
                                .id(2L)
                                .name("Meal2")
                                .build()
                ))
                .build();
        userEntity = UserEntity.builder()
                .id(1L)
                .username("user1@gmail.com")
                .password(passwordEncoder.encode("password"))
                .account(accountEntity)
                .build();
        account = Account.builder()
                .id(1L)
                .Email("user1@gmail.com")
                .FirstName("user1")
                .LastName("user1")
                .Age(20)
                .Height(180L)
                .Weight(80L)
                .Gender("male")
                .build();
    }

    @Test
    public void shouldCreateUser() {
        when(userRepository.save(any(UserEntity.class))).thenReturn(userEntity);
        when(accountRepository.save(any(AccountEntity.class))).thenReturn(accountEntity);
        CreateUserRequest createUserRequest = CreateUserRequest.builder()
                .email("user2@gmail.com")
                .password(passwordEncoder.encode("password"))
                .firstName("user1")
                .lastName("user1")
                .Age(20)
                .Height(180L)
                .Gender("male")
                .Weight(80L)
                .build();
        CreateUserResponce createUserResponce = createUserUseCase.createUser(createUserRequest);
        CreateUserResponce expected = CreateUserResponce.builder()
                .username("user2@gmail.com")
                .build();
        assertEquals(expected, createUserResponce);
        verify(accountRepository).save(any(AccountEntity.class));
        verify(userRepository).save(any(UserEntity.class));
    }

    @Test
    public void shouldThrowExceptionWhenUserAlreadyExists() {
        try{
            when(accountRepository.save(any(AccountEntity.class))).thenReturn(accountEntity);
            when(userRepository.save(any(UserEntity.class))).thenReturn(userEntity);
            when(accountRepository.existsByEmail(anyString())).thenReturn(false);
            CreateUserRequest createUserRequest = CreateUserRequest.builder()
                    .email(userEntity.getUsername()).build();
            createUserUseCase.createUser(createUserRequest);
        }
        catch (InvalidUserExeption e){
            assertEquals("Username or Email already exists", e.getMessage());
        }
    }
    @Test
    void shouldThrowExceptionWhenEmailAlreadyExists() {
        CreateUserRequest createUserRequest = CreateUserRequest.builder()
                .email(userEntity.getUsername())
                .password(passwordEncoder.encode("password"))
                .firstName("user1")
                .lastName("user1")
                .Age(20)
                .Weight(80L)
                .Height(180L)
                .Gender("Male")
                .build();
        when(accountRepository.existsByEmail(anyString())).thenReturn(true);
        assertThrows(InvalidUserExeption.class, () -> createUserUseCase.createUser(createUserRequest));
    }
}
