package com.example.myfitnesspal.ControllerTests;

import com.example.myfitnesspal.business.CreateUserUseCase;
import com.example.myfitnesspal.business.GetUsersUseCase;
import com.example.myfitnesspal.domain.CreateUserRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class UserControllerTests {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    CreateUserUseCase createUserUseCase;
    @MockBean
    GetUsersUseCase getUsersUseCase;

    @Test
    public void createUser() throws Exception {
        CreateUserRequest createUserRequest = CreateUserRequest.builder()
                .password("password")
                .email("user@gmail.com")
                .firstName("user")
                .lastName("user")
                .Weight(100L)
                .Height(100L)
                .Age(16)
                .Gender("Male")
                .build();
        mockMvc.perform(post("/users")
                        .contentType("application/json")
                        .content("""
                                 {
                                     "password": "password",
                                     "email": "user@gmail.com",
                                     "firstName": "user",
                                     "lastName": "user",
                                     "weight": 100,
                                     "height": 100,
                                     "age": 16,
                                     "gender":"Male"
                                     }
                                """))
                .andExpect(status().
                        isOk());
        verify(createUserUseCase).createUser(createUserRequest);
    }
    @Test
    @WithMockUser(username = "metodi@gmail.com", roles = {"ADMIN"})
    public void getUsers() throws Exception {
        mockMvc.perform(get("/users"))
                .andExpect(status().isOk());
        verify(getUsersUseCase).getUsers();
    }
    @Test
    @WithMockUser(username = "metodi@gmail.com", roles = {"ADMIN"})
    public void updateUser() throws Exception {
        mockMvc.perform(put("/users")
                        .contentType("application/json")
                        .content("""
                                 {
                                     "id": 7,
                                     "email": "user@gmail.com",
                                     "firstName": "User",
                                     "lastName": "userrrr",
                                     "age": 16,
                                     "weight": 100,
                                     "height": 100,
                                     "gender": "test"
                                     }
                                """))
                .andExpect(status().isNoContent());
    }
}
