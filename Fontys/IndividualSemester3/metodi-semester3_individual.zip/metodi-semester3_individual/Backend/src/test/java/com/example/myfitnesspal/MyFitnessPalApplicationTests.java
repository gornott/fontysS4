package com.example.myfitnesspal;

import com.example.myfitnesspal.repository.DietPlanEntity;
import com.example.myfitnesspal.repository.DietPlanRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import javax.persistence.EntityManager;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class DietPlanRepositoryTest {

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private DietPlanRepository dietPlanRepository;

    @Test
    void save_shouldSaveDietPlanWithAllFields() {
        DietPlanEntity dietPlan = DietPlanEntity.builder()
                .name("DietPlan1")
                .build();

        DietPlanEntity savedDietPlan = dietPlanRepository.save(dietPlan);
        assertNotNull(savedDietPlan.getId());

        savedDietPlan = entityManager.find(DietPlanEntity.class, savedDietPlan.getId());
        DietPlanEntity expectedDietPlan = DietPlanEntity.builder()
                .id(savedDietPlan.getId())
                .name("DietPlan1")
                .build();
        assertEquals(expectedDietPlan, savedDietPlan);
    }
    @Test
    void save_shouldSaveDietPlanWithOnlyName() {
        DietPlanEntity dietPlan = DietPlanEntity.builder()
                .name("DietPlan1")
                .build();

        DietPlanEntity savedDietPlan = dietPlanRepository.save(dietPlan);
        assertNotNull(savedDietPlan.getId());

        savedDietPlan = entityManager.find(DietPlanEntity.class, savedDietPlan.getId());
        DietPlanEntity expectedDietPlan = DietPlanEntity.builder()
                .id(savedDietPlan.getId())
                .name("DietPlan1")
                .build();
        assertEquals(expectedDietPlan, savedDietPlan);
    }
    @Test
    void getDietPlanById_shouldReturnDietPlan() {
        DietPlanEntity dietPlan = DietPlanEntity.builder()
                .name("DietPlan1")
                .build();

        DietPlanEntity savedDietPlan = dietPlanRepository.save(dietPlan);
        assertNotNull(savedDietPlan.getId());

        DietPlanEntity foundDietPlan = dietPlanRepository.findById(savedDietPlan.getId()).get();
        assertEquals(savedDietPlan, foundDietPlan);
    }

    @Test
void getDietPlanById_shouldReturnEmptyOptional() {
        Optional<DietPlanEntity> foundDietPlan = dietPlanRepository.findById(1L);
        assertEquals(Optional.empty(), foundDietPlan);
    }
    @Test
    void deleteDietPlanById_shouldDeleteDietPlan() {
        DietPlanEntity dietPlan = DietPlanEntity.builder()
                .name("DietPlan1")
                .build();

        DietPlanEntity savedDietPlan = dietPlanRepository.save(dietPlan);
        assertNotNull(savedDietPlan.getId());

        dietPlanRepository.deleteById(savedDietPlan.getId());
        Optional<DietPlanEntity> foundDietPlan = dietPlanRepository.findById(savedDietPlan.getId());
        assertEquals(Optional.empty(), foundDietPlan);
    }
}
