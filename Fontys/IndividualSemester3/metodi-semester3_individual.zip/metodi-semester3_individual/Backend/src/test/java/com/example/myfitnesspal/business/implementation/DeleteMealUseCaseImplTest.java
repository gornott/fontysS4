package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.business.exeption.MealNotFoundException;
import com.example.myfitnesspal.repository.MealEntity;
import com.example.myfitnesspal.repository.MealRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class DeleteMealUseCaseImplTest {
    @Mock
    private MealRepository mealRepository;
    @InjectMocks
    private DeleteMealUseCaseImpl deleteMealUseCase;

    @Test
    void deleteMeal_shouldDeleteMeal() {
        MealEntity mealEntity = MealEntity.builder()
                .id(1L)
                .name("Meal1")
                .build();
        deleteMealUseCase.deleteMeal(mealEntity.getId());
        verify(mealRepository).deleteById(1L);
    }
}
