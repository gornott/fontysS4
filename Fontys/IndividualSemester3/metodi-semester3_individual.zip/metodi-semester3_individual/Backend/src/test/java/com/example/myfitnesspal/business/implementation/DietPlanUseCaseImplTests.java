package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.business.exeption.InvalidDietPlanException;
import com.example.myfitnesspal.business.exeption.NotFoundExeption;
import com.example.myfitnesspal.domain.*;
import com.example.myfitnesspal.repository.DietPlanEntity;
import com.example.myfitnesspal.repository.DietPlanRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class DietPlanUseCaseImplTests {
    @Mock
    private DietPlanRepository dietPlanRepository;
    @InjectMocks
    private CreateDietPlanUseCaseImpl createDietPlanUseCase;
    @InjectMocks
    private DeleteDietPlanUseCaseImpl deleteDietPlanUseCase;
    @InjectMocks
    private UpdateDietPlanUseCaseImpl updateDietPlanUseCase;
    @InjectMocks
    private GetDietPlansUseCaseImpl getDietPlansUseCase;
    DietPlanEntity dietPlan;

    @BeforeEach
    void setUp() {
        dietPlan = DietPlanEntity.builder()
                .id(1L)
                .name("DietPlan1")
                .code("DP")
                .build();
    }

    @Test
    public void createDietPlan_shouldCreateDietPlan() {
        when(dietPlanRepository.save(any(DietPlanEntity.class))).thenReturn(dietPlan);
        CreateDietPlanRequest request = CreateDietPlanRequest.builder()
                .name("DietPlan1")
                .code("DP")
                .build();
        CreateDietPlanResponse result = createDietPlanUseCase.createDietPlan(request);
        CreateDietPlanResponse expected = CreateDietPlanResponse.builder()
                .id(1L)
                .name("DietPlan1")
                .code("DP")
                .build();
        assertEquals(expected, result);
    }

    @Test
    public void deleteDietPlan_shouldDeleteDietPlan() {
        deleteDietPlanUseCase.deleteDietPlan(dietPlan.getId());
        verify(dietPlanRepository).deleteById(1L);
    }
    @Test
    public void updateDietPlan_shouldUpdateDietPlan() {
        when(dietPlanRepository.findById(anyLong())).thenReturn(Optional.of(dietPlan));
        UpdateDietPlanRequest request = UpdateDietPlanRequest.builder()
                .dietPlanId(1L)
                .name("DietPlan11")
                .code("DP")
                .build();
        updateDietPlanUseCase.updateDietPlan(request);
        verify(dietPlanRepository).save(dietPlan);
    }
    @Test
    public void getDietPlans_shouldGetDietPlans() {
        when(dietPlanRepository.findAll()).thenReturn(List.of(dietPlan));
        GetDietPlansResponse result = getDietPlansUseCase.getDietPlans();
        GetDietPlansResponse expected = GetDietPlansResponse.builder()
                .dietPlans(List.of(DietPlan.builder()
                        .id(1L)
                        .name("DietPlan1")
                        .code("DP")
                        .build()))
                .build();
        assertEquals(expected, result);
    }
    @Test
    public void createDietPlan_shouldThrowException() {
        when(dietPlanRepository.existsByCode(anyString())).thenReturn(true);
        CreateDietPlanRequest request = CreateDietPlanRequest.builder()
                .name("DietPlan1")
                .code("DP")
                .build();
        assertThrows(InvalidDietPlanException.class, () -> createDietPlanUseCase.createDietPlan(request));
    }
    @Test
    public void updateDietPlan_shouldThrowException() {
        when(dietPlanRepository.findById(anyLong())).thenReturn(Optional.empty());
        UpdateDietPlanRequest request = UpdateDietPlanRequest.builder()
                .dietPlanId(2L)
                .name("DietPlan11")
                .code("DP")
                .build();
        assertThrows(NotFoundExeption.class, () -> updateDietPlanUseCase.updateDietPlan(request));
    }
}
