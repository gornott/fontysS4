package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.business.AccessTokenEncoder;
import com.example.myfitnesspal.business.exeption.InvalidCredentialsException;
import com.example.myfitnesspal.business.exeption.InvalidUserExeption;
import com.example.myfitnesspal.domain.AccessToken;
import com.example.myfitnesspal.domain.LoginRequest;
import com.example.myfitnesspal.domain.LoginResponse;
import com.example.myfitnesspal.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LoginUseCaseImplTest {
    @Mock
    private UserRepository userRepository;
    @Mock
    private AccessTokenEncoder accessTokenEncoder;
    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private LoginUseCaseImpl loginUseCase;


    UserEntity userEntity;
    @BeforeEach
    void setUp() {

        userEntity = UserEntity.builder()
                .id(1L)
                .username("user1@gmail.com")
                .password("password")
                .account(AccountEntity.builder()
                        .id(1L)
                        .email("user1@gmail.com")
                        .build())
                .userRoles(Set.of(
                        UserRoleEntity.builder()
                                .id(1L)
                                .role(RoleEnum.USER)
                                .build()
                ))
                .build();
    }

    @Test
    void login() {
        when(userRepository.findByUsername(anyString())).thenReturn(userEntity);
        when(passwordEncoder.matches(anyString(), anyString())).thenReturn(true);
        LoginRequest loginRequest = LoginRequest.builder()
                .username(userEntity.getUsername())
                .password("password")
                .build();
        LoginResponse loginResponse = loginUseCase.login(loginRequest);
        LoginResponse expected = LoginResponse.builder()
                .accessToken(accessTokenEncoder.encode(AccessToken.builder()
                        .subject("user1@gmail.com")
                        .roles(List.of("USER"))
                        .userId(userEntity.getAccount().getId())
                        .build()))
                .build();
        assertEquals(expected, loginResponse);
    }
    @Test
    void loginWrongPassword() {

        try {
            when(userRepository.findByUsername(anyString())).thenReturn(userEntity);
            when(passwordEncoder.matches(anyString(), anyString())).thenReturn(false);
            LoginRequest loginRequest = LoginRequest.builder()
                    .username(userEntity.getUsername())
                    .password("passwordd")
                    .build();
            LoginResponse loginResponse = loginUseCase.login(loginRequest);
        }
        catch (InvalidCredentialsException e){
            assertEquals("400 BAD_REQUEST \"INVALID_CREDENTIALS\"", e.getMessage());
        }
    }
    @Test
    void loginWrongUsername() {

        try {
            LoginRequest loginRequest = LoginRequest.builder()
                    .username(userEntity.getUsername())
                    .password("passwordd")
                    .build();
            LoginResponse loginResponse = loginUseCase.login(loginRequest);
        } catch (InvalidCredentialsException e) {
            assertEquals("400 BAD_REQUEST \"INVALID_CREDENTIALS\"", e.getMessage());
        }
    }
    @Test
    void loginWithOutUser(){
        UserEntity userEntity = UserEntity.builder()
                .username("user1@gmail.com")
                .password("password")
                .account(AccountEntity.builder()
                        .email("user1@gmail.com")
                        .build())
                .userRoles(Set.of(
                        UserRoleEntity.builder()
                                .id(1L)
                                .role(RoleEnum.USER)
                                .build()
                ))
                .build();
        when(userRepository.findByUsername(anyString())).thenReturn(userEntity);
        when(passwordEncoder.matches(anyString(), anyString())).thenReturn(true);
        LoginRequest loginRequest = LoginRequest.builder()
                .username(userEntity.getUsername())
                .password("password")
                .build();
        assertThrows(InvalidUserExeption.class, () -> loginUseCase.login(loginRequest));
    }
}