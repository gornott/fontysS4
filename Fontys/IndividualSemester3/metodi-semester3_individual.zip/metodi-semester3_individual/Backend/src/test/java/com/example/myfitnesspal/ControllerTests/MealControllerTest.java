package com.example.myfitnesspal.ControllerTests;

import com.example.myfitnesspal.business.CreateMealUseCase;
import com.example.myfitnesspal.business.DeleteMealUseCase;
import com.example.myfitnesspal.business.GetMealsUseCase;
import com.example.myfitnesspal.controller.MealController;
import com.example.myfitnesspal.domain.*;
import com.example.myfitnesspal.repository.MealEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithAnonymousUser;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Set;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MealControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private CreateMealUseCase createMealUseCase;
    @MockBean
    private GetMealsUseCase getMealUseCase;
    @MockBean
    private DeleteMealUseCase deleteMealUseCase;
    Meal meal;
    Account account;
    @BeforeEach
    public void setUp() {
        account = Account.builder()
                .id(1L)
                .build();
         meal = Meal.builder()
                .id(1L)
                .name("Meal1")
                .userId(1L)
                .calories(1000f)
                .totalNutrients(List.of(
                        Nutrient.builder()
                                .id(1L)
                                .label("Protein")
                                .quantity(100.0)
                                .unit("g")
                                .build(),
                        Nutrient.builder()
                                .id(2L)
                                .label("Carbs")
                                .quantity(100.0)
                                .unit("g")
                                .build(),
                        Nutrient.builder()
                                .id(3L)
                                .label("Fat")
                                .quantity(100.0)
                                .unit("g")
                                .build()
                ))
                 .userId(account.getId())
                .build();

    }
    @Test
    void getMeals_ReturnsMealsForUser() throws Exception {
        when(getMealUseCase.getMeals(anyLong(),anyString())).thenReturn(GetMealsResponse.builder()
                .meals(List.of(meal))
                .build());
        mockMvc.perform(get("/diary/1/asc"))
                .andExpect(status().isOk());
        verify(getMealUseCase).getMeals(anyLong(),anyString());
    }
    @Test
    void deleteMeal_ReturnsOk() throws Exception {
        mockMvc.perform(delete("/diary/1"))
                .andExpect(status().isNoContent());
        verify(deleteMealUseCase).deleteMeal(anyLong());
    }
    @Test
    @WithMockUser(username = "metodi@gmail.com", roles={"USER"})
    void createNewMeal_ReturnsOk() throws Exception {
        CreateMealRequest request = CreateMealRequest.builder()
                .calories(1000f)
                .name("Meal1")
                .totalNutrients(List.of(
                        Nutrient.builder()
                                .id(1L)
                                .label("Protein")
                                .quantity(100.0)
                                .unit("g")
                                .build(),
                        Nutrient.builder()
                                .id(2L)
                                .label("Carbs")
                                .quantity(100.0)
                                .unit("g")
                                .build(),
                        Nutrient.builder()
                                .id(3L)
                                .label("Fat")
                                .quantity(100.0)
                                .unit("g")
                                .build()
                ))
                .build();
        mockMvc.perform(post("/diary")
                .contentType("application/json")
                        .content("""
                                {
                                    "calories": 1000,
                                    "name": "Meal1",
                                    "totalNutrients": [
                                        {
                                            "id": 1,
                                            "label": "Protein",
                                            "quantity": 100.0,
                                            "unit": "g"
                                        },
                                        {
                                            "id": 2,
                                            "label": "Carbs",
                                            "quantity": 100.0,
                                            "unit": "g"
                                        },
                                        {
                                            "id": 3,
                                            "label": "Fat",
                                            "quantity": 100.0,
                                            "unit": "g"
                                        }
                                    ]
                                }
                                """))
                .andExpect(status().isCreated());
        verify(createMealUseCase).createMeal(request);
    }
    @Test
    @WithMockUser(username = "metodi@gmail.com", roles={"USER"})
    void createNewMeal_ReturnsBadRequest() throws Exception {
        CreateMealRequest request = CreateMealRequest.builder()
                .calories(1000f)
                .name("Meal1")
                .totalNutrients(List.of(
                        Nutrient.builder()
                                .id(1L)
                                .label("Protein")
                                .quantity(100.0)
                                .unit("g")
                                .build(),
                        Nutrient.builder()
                                .id(2L)
                                .label("Carbs")
                                .quantity(100.0)
                                .unit("g")
                                .build(),
                        Nutrient.builder()
                                .id(3L)
                                .label("Fat")
                                .quantity(100.0)
                                .unit("g")
                                .build()
                ))
                .build();
        mockMvc.perform(post("/diary")
                .contentType("application/json")
                .content(request.toString()))
                .andExpect(status().isBadRequest());
    }

}
