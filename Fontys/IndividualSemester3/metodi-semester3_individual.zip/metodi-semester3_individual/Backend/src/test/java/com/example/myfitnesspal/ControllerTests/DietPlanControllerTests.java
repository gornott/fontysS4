package com.example.myfitnesspal.ControllerTests;
import com.example.myfitnesspal.business.CreateDietPlanUseCase;
import com.example.myfitnesspal.business.DeleteDietPlanUseCase;
import com.example.myfitnesspal.business.GetDietPlansUseCase;
import com.example.myfitnesspal.business.UpdateDietPlanUseCase;
import com.example.myfitnesspal.domain.CreateDietPlanRequest;
import com.example.myfitnesspal.domain.DietPlan;
import com.example.myfitnesspal.domain.GetDietPlansResponse;
import com.example.myfitnesspal.domain.UpdateDietPlanRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class DietPlanControllerTests {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private CreateDietPlanUseCase createDietPlanUseCase;
    @MockBean
    private GetDietPlansUseCase getDietPlansUseCase;
    @MockBean
    private DeleteDietPlanUseCase deleteDietPlanUseCase;
    @MockBean
    private UpdateDietPlanUseCase updateDietPlanUseCase;
    DietPlan dietPlan;
    @BeforeEach
    public void setUp(){
        dietPlan = DietPlan.builder()
                .id(1L)
                .name("DietPlan1")
                .build();
    }
    @Test
    public void testGetDietPlans() throws Exception {
        when(getDietPlansUseCase.getDietPlans()).thenReturn(GetDietPlansResponse.builder()
                .dietPlans(List.of(dietPlan))
                .build());
        mockMvc.perform(get("/plans"))
                .andExpect(status().isOk());
        verify(getDietPlansUseCase).getDietPlans();
    }
    @Test
    public void testDeleteDietPlan() throws Exception {
        mockMvc.perform(delete("/plans/1"))
                .andExpect(status().isNoContent());
        verify(deleteDietPlanUseCase).deleteDietPlan(anyLong());
    }
    @Test
    public void testUpdateDietPlan() throws Exception {
        UpdateDietPlanRequest updateDietPlanRequest = UpdateDietPlanRequest.builder()
                .dietPlanId(1L)
                .name("DietPlan1")
                .code("DP")
                .build();
        mockMvc.perform(put("/plans/1")
                        .contentType("application/json")
                        .content("""
                                {
                                    "id": 1,
                                    "code": "DP",
                                    "name": "DietPlan1"

                                }
                                """))
                .andExpect(status().isNoContent());
        verify(updateDietPlanUseCase).updateDietPlan(updateDietPlanRequest);
    }
    @Test
    public void testCreateDietPlan() throws Exception {
        CreateDietPlanRequest createDietPlanRequest = CreateDietPlanRequest.builder()
                .code("DP")
                .name("DietPlan1")
                .build();
        mockMvc.perform(post("/plans").contentType("application/json").content("""
                {
                    "name": "DietPlan1",
                    "code": "DP"
                }
                """))
                .andExpect(status().isCreated());
        verify(createDietPlanUseCase).createDietPlan(createDietPlanRequest);
    }

}
