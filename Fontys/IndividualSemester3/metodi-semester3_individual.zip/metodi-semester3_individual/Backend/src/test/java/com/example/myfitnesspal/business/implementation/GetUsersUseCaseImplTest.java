package com.example.myfitnesspal.business.implementation;
import com.example.myfitnesspal.domain.AccessToken;
import com.example.myfitnesspal.domain.Account;
import com.example.myfitnesspal.domain.GetAllUsersResponse;
import com.example.myfitnesspal.repository.AccountEntity;
import com.example.myfitnesspal.repository.AccountRepository;
import com.example.myfitnesspal.repository.UserEntity;
import com.example.myfitnesspal.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.test.context.support.WithMockUser;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class GetUsersUseCaseImplTest {
    @Mock
    private UserRepository userRepository;
    @Mock
    private AccountRepository accountRepository;
    @Mock
    private PasswordEncoder passwordEncoder;
    @InjectMocks
    private GetUsersUseCaseImpl getUsersUseCase;


   AccountEntity accountEntity;
   UserEntity userEntity;
   Account account;
    @BeforeEach
    void setUp() {
        userEntity = UserEntity.builder()
                .id(1L)
                .username("user@gmail.com")
                .password(passwordEncoder.encode("password"))
                .account(accountEntity)
                .build();
        accountEntity = AccountEntity.builder()
                .id(1L)
                .email("username")
                .FirstName("firstname")
                .LastName("lastname")
                .Age(20)
                .Weight(80L)
                .Height(180L)
                .Gender("Male")
                .build();
        account = AccountConverter.convert(accountEntity);

    }
    @Test
    void getUsers_shouldReturnAllUsers() {

       when(accountRepository.findAll()).thenReturn(List.of(accountEntity));
        GetAllUsersResponse response = getUsersUseCase.getUsers();
        assertEquals(1, response.getAccounts().size());
        assertEquals(account, response.getAccounts().get(0));
    }
    @Test
    void getUsers_shouldReturnEmptyList() {
        when(accountRepository.findAll()).thenReturn(List.of());
        GetAllUsersResponse response = getUsersUseCase.getUsers();
        assertEquals(0, response.getAccounts().size());
    }
    @Test
    void convertAccount_shouldConvertAccountEntityToAccount() {
        Account account = AccountConverter.convert(accountEntity);
        assertEquals(accountEntity.getId(), account.getId());
        assertEquals(accountEntity.getEmail(), account.getEmail());
        assertEquals(accountEntity.getFirstName(), account.getFirstName());
        assertEquals(accountEntity.getLastName(), account.getLastName());
        assertEquals(accountEntity.getAge(), account.getAge());
        assertEquals(accountEntity.getWeight(), account.getWeight());
        assertEquals(accountEntity.getHeight(), account.getHeight());
        assertEquals(accountEntity.getGender(), account.getGender());
    }
}
