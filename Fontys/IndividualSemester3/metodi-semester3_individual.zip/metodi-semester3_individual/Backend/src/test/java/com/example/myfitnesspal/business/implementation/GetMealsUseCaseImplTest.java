package com.example.myfitnesspal.business.implementation;
import com.example.myfitnesspal.domain.GetMealsResponse;
import com.example.myfitnesspal.domain.Meal;
import com.example.myfitnesspal.repository.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class GetMealsUseCaseImplTest {
    @Mock
    private MealRepository mealRepository;
    @InjectMocks
    private GetMealsUseCaseImpl getMealsUseCase;
    @Mock
    private UserRepository userRepository;


    @Test
    void getMeals_shouldReturnMeals() {

        MealEntity mealEntity = MealEntity.builder()
                .name("Meal1")
                .calories(10F)
                .totalNutrients(List.of(
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Protein")
                                .quantity(10.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Carbs")
                                .quantity(20.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Fat")
                                .quantity(30.0)
                                .unit("g")
                                .build()
                        ))
                .account(AccountEntity.builder()
                        .id(1L)
                        .build())
                .build();
        MealEntity mealEntity2 = MealEntity.builder()
                .name("Meal2")
                .calories(100F)
                .totalNutrients(List.of(
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Protein")
                                .quantity(10.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Carbs")
                                .quantity(20.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Fat")
                                .quantity(30.0)
                                .unit("g")
                                .build()
                )).account(AccountEntity.builder()
                        .id(1L)
                        .build())
                .build();
        AccountEntity user = AccountEntity.builder()
                .id(1L).build();
        when(mealRepository.findByAccountId(user.getId(), Sort.by("calories").ascending()))
                .thenReturn(List.of(mealEntity, mealEntity2));
        GetMealsResponse response = getMealsUseCase.getMeals(user.getId(), "asc");

        Meal meal = Meal.builder()
                .name("Meal1")
                .calories(10F)
                .totalNutrients(
                        List.of(
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .build())
                                        .label("Protein")
                                        .quantity(10.0)
                                        .unit("g")
                                        .build(),
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .build())
                                        .label("Carbs")
                                        .quantity(20.0)
                                        .unit("g")
                                        .build(),
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .build())
                                        .label("Fat")
                                        .quantity(30.0)
                                        .unit("g")
                                        .build()
                ).stream().map(NutrientConverter::convertNut).toList())
                .userId(1L)
                .build();
        Meal meal2 = Meal.builder()
                .name("Meal2")
                .calories(100F)
                .totalNutrients(
                        List.of(
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .id(1L)
                                                .build())
                                        .label("Protein")
                                        .quantity(10.0)
                                        .unit("g")
                                        .build(),
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .id(1L)
                                                .build())
                                        .label("Carbs")
                                        .quantity(20.0)
                                        .unit("g")
                                        .build(),
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .id(1L)
                                                .build())
                                        .label("Fat")
                                        .quantity(30.0)
                                        .unit("g")
                                        .build()
                        ).stream().map(NutrientConverter::convertNut).toList())
                .userId(1L)
                .build();
        GetMealsResponse expectedResponse = GetMealsResponse.builder()
                .meals(List.of(meal, meal2))
                .build();
        assertEquals(expectedResponse, response);
        verify(mealRepository).findByAccountId(1L,Sort.by("calories").ascending());
    }
    @Test
    void getMeals_shouldReturnMealsByNameInAscendingOrder() {

        MealEntity mealEntity = MealEntity.builder()
                .name("Meal1")
                .calories(10F)
                .totalNutrients(List.of(
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Protein")
                                .quantity(10.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Carbs")
                                .quantity(20.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Fat")
                                .quantity(30.0)
                                .unit("g")
                                .build()
                ))
                .account(AccountEntity.builder()
                        .id(1L)
                        .build())
                .build();
        MealEntity mealEntity2 = MealEntity.builder()
                .name("Meal2")
                .calories(100F)
                .totalNutrients(List.of(
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Protein")
                                .quantity(10.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Carbs")
                                .quantity(20.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Fat")
                                .quantity(30.0)
                                .unit("g")
                                .build()
                )).account(AccountEntity.builder()
                        .id(1L)
                        .build())
                .build();
        AccountEntity user = AccountEntity.builder()
                .id(1L).build();
        when(mealRepository.findByAccountId(user.getId(), Sort.by("name").ascending()))
                .thenReturn(List.of(mealEntity, mealEntity2));
        GetMealsResponse response = getMealsUseCase.getMeals(user.getId(), "name");

        Meal meal = Meal.builder()
                .name("Meal1")
                .calories(10F)
                .totalNutrients(
                        List.of(
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .build())
                                        .label("Protein")
                                        .quantity(10.0)
                                        .unit("g")
                                        .build(),
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .build())
                                        .label("Carbs")
                                        .quantity(20.0)
                                        .unit("g")
                                        .build(),
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .build())
                                        .label("Fat")
                                        .quantity(30.0)
                                        .unit("g")
                                        .build()
                        ).stream().map(NutrientConverter::convertNut).toList())
                .userId(1L)
                .build();
        Meal meal2 = Meal.builder()
                .name("Meal2")
                .calories(100F)
                .totalNutrients(
                        List.of(
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .id(1L)
                                                .build())
                                        .label("Protein")
                                        .quantity(10.0)
                                        .unit("g")
                                        .build(),
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .id(1L)
                                                .build())
                                        .label("Carbs")
                                        .quantity(20.0)
                                        .unit("g")
                                        .build(),
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .id(1L)
                                                .build())
                                        .label("Fat")
                                        .quantity(30.0)
                                        .unit("g")
                                        .build()
                        ).stream().map(NutrientConverter::convertNut).toList())
                .userId(1L)
                .build();
        GetMealsResponse expectedResponse = GetMealsResponse.builder()
                .meals(List.of(meal, meal2))
                .build();
        assertEquals(expectedResponse, response);
        verify(mealRepository).findByAccountId(1L,Sort.by("name").ascending());
    }
    @Test
    void getMeals_shouldReturnMealsOrderedByCaloriesInDescendingOrder() {

        MealEntity mealEntity = MealEntity.builder()
                .name("Meal1")
                .calories(10F)
                .totalNutrients(List.of(
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Protein")
                                .quantity(10.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Carbs")
                                .quantity(20.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Fat")
                                .quantity(30.0)
                                .unit("g")
                                .build()
                ))
                .account(AccountEntity.builder()
                        .id(1L)
                        .build())
                .build();
        MealEntity mealEntity2 = MealEntity.builder()
                .name("Meal2")
                .calories(100F)
                .totalNutrients(List.of(
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Protein")
                                .quantity(10.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Carbs")
                                .quantity(20.0)
                                .unit("g")
                                .build(),
                        NutritionEntity.builder()
                                .meal(MealEntity.builder()
                                        .build())
                                .label("Fat")
                                .quantity(30.0)
                                .unit("g")
                                .build()
                )).account(AccountEntity.builder()
                        .id(1L)
                        .build())
                .build();
        AccountEntity user = AccountEntity.builder()
                .id(1L).build();
        when(mealRepository.findByAccountId(user.getId(), Sort.by("calories").descending()))
                .thenReturn(List.of(mealEntity, mealEntity2));
        GetMealsResponse response = getMealsUseCase.getMeals(user.getId(), "desc");

        Meal meal = Meal.builder()
                .name("Meal1")
                .calories(10F)
                .totalNutrients(
                        List.of(
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .build())
                                        .label("Protein")
                                        .quantity(10.0)
                                        .unit("g")
                                        .build(),
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .build())
                                        .label("Carbs")
                                        .quantity(20.0)
                                        .unit("g")
                                        .build(),
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .build())
                                        .label("Fat")
                                        .quantity(30.0)
                                        .unit("g")
                                        .build()
                        ).stream().map(NutrientConverter::convertNut).toList())
                .userId(1L)
                .build();
        Meal meal2 = Meal.builder()
                .name("Meal2")
                .calories(100F)
                .totalNutrients(
                        List.of(
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .id(1L)
                                                .build())
                                        .label("Protein")
                                        .quantity(10.0)
                                        .unit("g")
                                        .build(),
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .id(1L)
                                                .build())
                                        .label("Carbs")
                                        .quantity(20.0)
                                        .unit("g")
                                        .build(),
                                NutritionEntity.builder()
                                        .meal(MealEntity.builder()
                                                .id(1L)
                                                .build())
                                        .label("Fat")
                                        .quantity(30.0)
                                        .unit("g")
                                        .build()
                        ).stream().map(NutrientConverter::convertNut).toList())
                .userId(1L)
                .build();
        GetMealsResponse expectedResponse = GetMealsResponse.builder()
                .meals(List.of(meal, meal2))
                .build();
        assertEquals(expectedResponse, response);
        verify(mealRepository).findByAccountId(1L,Sort.by("calories").descending());
    }
    @Test
    void getMeals_shouldReturnEmptyList() {
        AccountEntity user = AccountEntity.builder()
                .id(2L)
                .build();
        when(mealRepository.findAll())
                .thenReturn(List.of());
        assertEquals(mealRepository.findAll().size(), 0);
        verify(mealRepository).findAll();
    }
}

