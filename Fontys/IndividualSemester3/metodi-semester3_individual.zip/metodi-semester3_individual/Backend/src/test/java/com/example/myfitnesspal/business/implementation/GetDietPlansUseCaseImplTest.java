package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.domain.CreateDietPlanRequest;
import com.example.myfitnesspal.domain.DietPlan;
import com.example.myfitnesspal.domain.GetDietPlansResponse;
import com.example.myfitnesspal.repository.DietPlanEntity;
import com.example.myfitnesspal.repository.DietPlanRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;


import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class GetDietPlansUseCaseImplTest {
    @Mock
    private DietPlanRepository dietPlanRepository;
    @InjectMocks
    private CreateDietPlanUseCaseImpl createDietPlanUseCase;
    @InjectMocks
    private DeleteDietPlanUseCaseImpl deleteDietPlanUseCase;

    @Test
    void getDietPlans_shouldReturnDietPlans() {
        DietPlanEntity dietPlanEntity = DietPlanEntity.builder()
                .name("DietPlan1")
                .build();
        DietPlanEntity dietPlanEntity2 = DietPlanEntity.builder()
                .name("DietPlan2")
                .build();
        when(dietPlanRepository.findAll())
                .thenReturn(List.of(dietPlanEntity, dietPlanEntity2));
        GetDietPlansUseCaseImpl getDietPlansUseCase = new GetDietPlansUseCaseImpl(dietPlanRepository);
        GetDietPlansResponse response = getDietPlansUseCase.getDietPlans();

        DietPlan dietPlan = DietPlan.builder()
                .name("DietPlan1")
                .build();
        DietPlan dietPlan2 = DietPlan.builder()
                .name("DietPlan2")
                .build();
        GetDietPlansResponse expectedResponse = GetDietPlansResponse.builder()
                .dietPlans(List.of(dietPlan, dietPlan2))
                .build();
        assertEquals(expectedResponse, response);
        verify(dietPlanRepository).findAll();
    }
    @Test
    void getDietPlans_shouldReturnEmptyList() {
        when(dietPlanRepository.findAll())
                .thenReturn(List.of());
        GetDietPlansUseCaseImpl getDietPlansUseCase = new GetDietPlansUseCaseImpl(dietPlanRepository);
        GetDietPlansResponse response = getDietPlansUseCase.getDietPlans();

        GetDietPlansResponse expectedResponse = GetDietPlansResponse.builder()
                .dietPlans(List.of())
                .build();
        assertEquals(expectedResponse, response);
        verify(dietPlanRepository).findAll();
    }

    @Test
    void createDietPlan_shouldCreateDietPlan() {
        DietPlanEntity dietPlanEntity = DietPlanEntity.builder()
                .name("DietPlan1")
                .build();
        when(dietPlanRepository.save(dietPlanEntity))
                .thenReturn(dietPlanEntity);
        CreateDietPlanRequest dietPlan = CreateDietPlanRequest.builder()
                .name("DietPlan1")
                .build();
        createDietPlanUseCase.createDietPlan(dietPlan);
        verify(dietPlanRepository).save(dietPlanEntity);
    }


}
