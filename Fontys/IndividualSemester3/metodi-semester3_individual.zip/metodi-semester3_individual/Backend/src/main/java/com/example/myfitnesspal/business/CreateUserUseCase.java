package com.example.myfitnesspal.business;

import com.example.myfitnesspal.domain.CreateUserRequest;
import com.example.myfitnesspal.domain.CreateUserResponce;

public interface CreateUserUseCase {
    CreateUserResponce createUser(CreateUserRequest createUserRequest);
}
