package com.example.myfitnesspal.business;

import com.example.myfitnesspal.domain.Account;

import java.util.Optional;

public interface GetUserUseCase {
    Optional<Account> getUser(long userId);
}
