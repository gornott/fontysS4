package com.example.myfitnesspal.repository;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
@Entity
@Table(name = "nutrients")
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NutritionEntity {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY )
    @Column(name = "id")
    private Long id;
    @ManyToOne
    @JoinColumn(name = "meal_id")
    private MealEntity meal;
    @NotBlank
    @Length(min = 2, max = 50)
    @Column(name = "name")
    private String label;
    @Column(name = "quantity")
    private Double quantity;
    @NotBlank
    @Column(name = "unit")
    private String unit;

}
