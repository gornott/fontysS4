package com.example.myfitnesspal.business.implementation;

public class GetUserUseCaseImpl {
    //Empty because it is TODO
}
