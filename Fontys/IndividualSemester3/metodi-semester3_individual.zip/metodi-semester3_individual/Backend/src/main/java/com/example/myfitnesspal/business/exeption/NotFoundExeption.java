package com.example.myfitnesspal.business.exeption;

public class NotFoundExeption extends RuntimeException {
    public NotFoundExeption(String errorCause) {
        super(errorCause);
    }
}

