package com.example.myfitnesspal.business;

import com.example.myfitnesspal.domain.CreateDietPlanRequest;
import com.example.myfitnesspal.domain.CreateDietPlanResponse;

public interface CreateDietPlanUseCase {
    CreateDietPlanResponse createDietPlan(CreateDietPlanRequest request);
}