package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.business.CreateDietPlanUseCase;
import com.example.myfitnesspal.business.exeption.InvalidDietPlanException;
import com.example.myfitnesspal.domain.CreateDietPlanRequest;
import com.example.myfitnesspal.repository.DietPlanRepository;
import com.example.myfitnesspal.domain.CreateDietPlanResponse;
import com.example.myfitnesspal.repository.DietPlanEntity;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@AllArgsConstructor
public class CreateDietPlanUseCaseImpl implements CreateDietPlanUseCase {

    private  final DietPlanRepository dietPlanRepository;

    @Transactional
    @Override
    public CreateDietPlanResponse createDietPlan(CreateDietPlanRequest request) {

        if (existsByCode(request.getCode())) {
            throw new InvalidDietPlanException("CODE_DUPLICATED");
        }

        DietPlanEntity newPlan = DietPlanEntity.builder()
                .name(request.getName())
                .code(request.getCode())
                .build();

        DietPlanEntity savedDietPlan = save(newPlan);

        return CreateDietPlanResponse.builder()
                .id(savedDietPlan.getId())
                .code(savedDietPlan.getCode())
                .name(savedDietPlan.getName())
                .build();
    }

    private DietPlanEntity save(DietPlanEntity dietPlan) {
        return dietPlanRepository.save(dietPlan);
    }

    private boolean existsByCode(String dietCode) {
        return dietPlanRepository.existsByCode(dietCode);
    }
}

