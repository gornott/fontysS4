package com.example.myfitnesspal.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateDietPlanRequest {
    private Long dietPlanId;
    @NotNull
    private String code;
    @NotNull
    private String name;
}
