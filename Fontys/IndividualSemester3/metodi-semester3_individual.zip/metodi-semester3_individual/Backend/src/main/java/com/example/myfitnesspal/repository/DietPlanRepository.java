package com.example.myfitnesspal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.myfitnesspal.repository.DietPlanEntity;
import org.springframework.stereotype.Repository;

@Repository
public interface DietPlanRepository extends JpaRepository<DietPlanEntity,Long> {
    boolean existsByCode(String code);
}
