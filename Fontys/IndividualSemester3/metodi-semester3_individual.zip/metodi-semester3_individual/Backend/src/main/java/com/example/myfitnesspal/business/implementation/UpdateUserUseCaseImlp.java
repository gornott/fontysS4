package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.business.UpdateUserUseCase;
import com.example.myfitnesspal.business.exeption.InvalidUserExeption;
import com.example.myfitnesspal.domain.Account;
import com.example.myfitnesspal.domain.UpdateUserRequest;
import com.example.myfitnesspal.repository.AccountEntity;
import com.example.myfitnesspal.repository.AccountRepository;
import com.example.myfitnesspal.repository.UserEntity;
import com.example.myfitnesspal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UpdateUserUseCaseImlp implements UpdateUserUseCase {
    private final AccountRepository accountRepository;
    private final UserRepository userRepository;


    @Override
    public void updateUser(UpdateUserRequest request) {
       Optional<UserEntity> userEntity = userRepository.findById(request.getId());
        Optional<AccountEntity> acc = accountRepository.findById(request.getId());
        if (acc.isEmpty() || userEntity.isEmpty()) {
            throw new InvalidUserExeption("USER_ID_INVALID");
        }
        AccountEntity user = acc.get();
        updateFields(request, user, userEntity.get());
    }

    private void updateFields(UpdateUserRequest request, AccountEntity user, UserEntity userEntity1) {
        user.setEmail(request.getEmail());
        userEntity1.setUsername(request.getEmail());
        userEntity1.setPassword(request.getPassword());
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setAge(request.getAge());
        user.setGender(request.getGender());
        user.setWeight(request.getWeight());
        user.setHeight(request.getHeight());
        accountRepository.save(user);
    }
}