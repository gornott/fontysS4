package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.business.DeleteMealUseCase;
import com.example.myfitnesspal.repository.MealRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class DeleteMealUseCaseImpl implements DeleteMealUseCase {

    private final MealRepository mealRepository;

    @Override
    public void deleteMeal(Long id) {
        this.mealRepository.deleteById(id);
    }
}

