package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.business.AccessTokenEncoder;
import com.example.myfitnesspal.business.LoginUseCase;
import com.example.myfitnesspal.business.exeption.InvalidCredentialsException;
import com.example.myfitnesspal.business.exeption.InvalidUserExeption;
import com.example.myfitnesspal.domain.AccessToken;
import com.example.myfitnesspal.domain.LoginRequest;
import com.example.myfitnesspal.domain.LoginResponse;
import com.example.myfitnesspal.repository.UserEntity;
import com.example.myfitnesspal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class LoginUseCaseImpl implements LoginUseCase {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AccessTokenEncoder accessTokenEncoder;

    @Override
    public LoginResponse login(LoginRequest loginRequest) {
        UserEntity user = userRepository.findByUsername(loginRequest.getUsername());
        if (user == null) {
            throw new InvalidCredentialsException();
        }

        if (!matchesPassword(loginRequest.getPassword(), user.getPassword())) {
            throw new InvalidCredentialsException();
        }

        String accessToken = generateAccessToken(user);
        return LoginResponse.builder().accessToken(accessToken).build();
    }

    private boolean matchesPassword(String rawPassword, String encodedPassword) {
        return passwordEncoder.matches(rawPassword, encodedPassword);
    }

    private String generateAccessToken(UserEntity user) {
        Long userId = user.getAccount() != null ? user.getAccount().getId() : null ;
        if(userId == null) {
            throw new InvalidUserExeption("Invalid user");
        }
        List<String> roles = user.getUserRoles().stream()
                .map(userRole -> userRole.getRole().toString())
                .toList();

        return accessTokenEncoder.encode(
                AccessToken.builder()
                        .subject(user.getUsername())
                        .roles(roles)
                        .userId(userId)
                        .build());
    }

}
