package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.business.CreateUserUseCase;
import com.example.myfitnesspal.business.exeption.InvalidUserExeption;
import com.example.myfitnesspal.domain.CreateUserRequest;
import com.example.myfitnesspal.domain.CreateUserResponce;
import com.example.myfitnesspal.repository.*;
import lombok.AllArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Set;

@Service
@AllArgsConstructor
public class CreateUserUseCaseImpl implements CreateUserUseCase {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AccountRepository accountRepository;

    @Transactional
    @Override
    public CreateUserResponce createUser(CreateUserRequest createUserRequest) {
        if(accountRepository.existsByEmail(createUserRequest.getEmail())){
            throw new InvalidUserExeption("Username or Email already exists");
        }
        AccountEntity acc = saveNewAccount(createUserRequest);
        saveNewUser(acc, createUserRequest.getPassword());
        return CreateUserResponce.builder()
                .id(acc.getId())
                .username(acc.getEmail())
                .build();
    }
    private void saveNewUser(AccountEntity user, String password) {
        String encodedPassword = passwordEncoder.encode(password);

        UserEntity newUser = UserEntity.builder()
                .username(user.getEmail())
                .password(encodedPassword)
                .account(user)
                .build();

        newUser.setUserRoles(Set.of(
                UserRoleEntity.builder()
                        .user(newUser)
                        .role(RoleEnum.USER)
                        .build()));
        userRepository.save(newUser);
    }
    private AccountEntity saveNewAccount(CreateUserRequest request) {
        AccountEntity accountEntity = AccountEntity.builder()
                .FirstName(request.getFirstName())
                .LastName(request.getLastName())
                .Age(request.getAge())
                .Height(request.getHeight())
                .Weight(request.getWeight())
                .email(request.getEmail())
                .Gender(request.getGender())
                .build();
        accountRepository.save(accountEntity);
        return accountEntity;
    }
}
