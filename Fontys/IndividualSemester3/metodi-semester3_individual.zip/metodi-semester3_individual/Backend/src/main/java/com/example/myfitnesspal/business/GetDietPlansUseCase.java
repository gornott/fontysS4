package com.example.myfitnesspal.business;

import com.example.myfitnesspal.domain.GetDietPlansResponse;

public interface GetDietPlansUseCase {
    GetDietPlansResponse getDietPlans();
}
