package com.example.myfitnesspal.domain;

import com.example.myfitnesspal.repository.NutritionEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateMealResponse {
    private Long id;
    private String name;
    private Float calories;
    private List<Nutrient> totalNutrients;

    private Long user_id;

}
