package com.example.myfitnesspal.business;


import com.example.myfitnesspal.domain.AccessToken;

public interface AccessTokenDecoder {
    AccessToken decode(String accessTokenEncoded);

}
