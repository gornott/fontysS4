package com.example.myfitnesspal.business;

public interface DeleteMealUseCase {
    void deleteMeal(Long id);
}
