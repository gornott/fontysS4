package com.example.myfitnesspal.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NutritionRepository extends JpaRepository<NutritionEntity, Long> {
    boolean existsById(Long id);
}

