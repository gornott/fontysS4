package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.business.GetDietPlansUseCase;
import com.example.myfitnesspal.domain.DietPlan;
import com.example.myfitnesspal.domain.GetDietPlansResponse;
import com.example.myfitnesspal.repository.DietPlanEntity;
import com.example.myfitnesspal.repository.DietPlanRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class GetDietPlansUseCaseImpl implements GetDietPlansUseCase {
    private  final DietPlanRepository countryRepository;
    @Override
    public GetDietPlansResponse getDietPlans() {
        List<DietPlan> dietPlans = findAll()
                .stream()
                .map(DietPlanConverter::convert)
                .toList();

        return GetDietPlansResponse.builder()
                .dietPlans(dietPlans)
                .build();
    }

    private List<DietPlanEntity> findAll() {
        return countryRepository.findAll();
    }


}
