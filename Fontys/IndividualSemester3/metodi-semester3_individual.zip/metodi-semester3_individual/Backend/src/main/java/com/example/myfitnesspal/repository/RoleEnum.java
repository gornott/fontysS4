package com.example.myfitnesspal.repository;

public enum RoleEnum {
    USER,
    ADMIN
}
