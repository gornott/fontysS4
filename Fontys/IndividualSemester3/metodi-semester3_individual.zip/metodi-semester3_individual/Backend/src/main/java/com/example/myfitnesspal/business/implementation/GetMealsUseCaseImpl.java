package com.example.myfitnesspal.business.implementation;
import com.example.myfitnesspal.business.GetMealsUseCase;
import com.example.myfitnesspal.domain.GetMealsResponse;
import com.example.myfitnesspal.domain.Meal;
import com.example.myfitnesspal.repository.MealEntity;
import com.example.myfitnesspal.repository.MealRepository;
import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class GetMealsUseCaseImpl implements GetMealsUseCase {
    private final MealRepository mealRepository;
    @Override
    public GetMealsResponse getMeals(Long id, String order) {
        Sort sort = switch (order) {
            case "asc" -> Sort.by("calories").ascending();
            case "desc" -> Sort.by("calories").descending();
            case "name" -> Sort.by("name").ascending();
            default -> Sort.by("id").ascending();
        };

        List<Meal> meals = mealRepository.findByAccountId(id, sort)
                .stream()
                .map(MealConverter::convert)
                .toList();
        return GetMealsResponse.builder()
                .meals(meals)
                .build();
    }
    private List<MealEntity> findAll() {
        return mealRepository.findAll();
    }
}

