package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.domain.Nutrient;
import com.example.myfitnesspal.repository.NutritionEntity;



final class NutrientConverter {
    private NutrientConverter() {
    }
    public static Nutrient convertNut(NutritionEntity nutrient) {
        return Nutrient.builder()
                .id(nutrient.getId())
                .label(nutrient.getLabel())
                .quantity(nutrient.getQuantity())
                .unit(nutrient.getUnit())
                .build();
    }
}
