package com.example.myfitnesspal.business.exeption;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class MealNotFoundException extends ResponseStatusException {
    public MealNotFoundException() {
        super(HttpStatus.NOT_FOUND, "MEAL_NOT_FOUND");
    }
}


