package com.example.myfitnesspal.repository;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Set;

@Entity
@Table(name = "account")
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    @NotNull
    @Column(name = "first_Name")
    private String FirstName;
    @NotNull
    @Column(name = "last_Name")
    private String LastName;
    @NotNull
    @Column(name = "Email")
    private String email;
    @NotNull
    @Column(name = "Weight")
    private Long Weight;
    @NotNull
    @Column(name = "Height")
    private Long Height;
    @NotNull
    @Column(name = "Age")
    private Integer Age;
    @NotNull
    @Column(name = "Gender")
    private String Gender;
    @OneToMany(cascade = CascadeType.REMOVE,targetEntity = MealEntity.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "account_id")
    private Set<MealEntity> meals;
}
