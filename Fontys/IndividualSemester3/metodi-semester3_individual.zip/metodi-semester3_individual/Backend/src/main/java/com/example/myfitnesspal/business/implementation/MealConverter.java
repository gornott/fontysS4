package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.domain.Meal;
import com.example.myfitnesspal.domain.Nutrient;
import com.example.myfitnesspal.repository.MealEntity;
import com.example.myfitnesspal.repository.NutritionEntity;

final class MealConverter {
    private MealConverter() {
    }

    public static Meal convert(MealEntity mealEntity) {
        return Meal.builder()
                .id(mealEntity.getId())
                .name(mealEntity.getName())
                .calories(mealEntity.getCalories())
                .totalNutrients(mealEntity.getTotalNutrients().stream().map(NutrientConverter::convertNut).toList())
                .userId(mealEntity.getAccount().getId())
                .build();
    }

}
