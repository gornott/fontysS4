package com.example.myfitnesspal.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateDietPlanResponse {
    private Long id;
    private String code;
    private String name;
}