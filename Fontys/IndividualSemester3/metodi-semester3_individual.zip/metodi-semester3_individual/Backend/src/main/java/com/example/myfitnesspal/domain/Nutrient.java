package com.example.myfitnesspal.domain;

import com.example.myfitnesspal.repository.MealEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Nutrient {
    private Long id;
    private MealEntity mealId;
    private String label;
    private Double quantity;
    private String unit;
}
