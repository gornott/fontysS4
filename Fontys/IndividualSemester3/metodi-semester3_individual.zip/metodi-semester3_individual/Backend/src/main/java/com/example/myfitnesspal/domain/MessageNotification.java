package com.example.myfitnesspal.domain;

import lombok.Data;

@Data
public class MessageNotification {
    private String id;
    private String from;
    private String to;
    private String text;
}
