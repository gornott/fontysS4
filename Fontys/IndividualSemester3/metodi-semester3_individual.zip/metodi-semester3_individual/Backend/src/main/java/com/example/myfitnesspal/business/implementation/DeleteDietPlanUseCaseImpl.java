package com.example.myfitnesspal.business.implementation;

import com.example.myfitnesspal.business.DeleteDietPlanUseCase;
import com.example.myfitnesspal.repository.DietPlanRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class DeleteDietPlanUseCaseImpl implements DeleteDietPlanUseCase {

    private final DietPlanRepository dietPlanRepository;

    @Override
    public void deleteDietPlan(Long id) {
        this.dietPlanRepository.deleteById(id);
    }
}

