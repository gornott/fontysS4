package com.example.myfitnesspal.business.exeption;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class InvalidUserExeption extends ResponseStatusException {
    public InvalidUserExeption(String errorCode) {
        super(HttpStatus.BAD_REQUEST, errorCode);
    }
}

