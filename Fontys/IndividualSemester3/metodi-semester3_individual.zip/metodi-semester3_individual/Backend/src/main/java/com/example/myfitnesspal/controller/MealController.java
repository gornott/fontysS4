package com.example.myfitnesspal.controller;

import com.example.myfitnesspal.business.DeleteMealUseCase;
import com.example.myfitnesspal.business.CreateMealUseCase;
import com.example.myfitnesspal.config.security.isauthenticated.IsAuthenticated;
import com.example.myfitnesspal.domain.*;
import com.example.myfitnesspal.business.GetMealsUseCase;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;


import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;

@RestController
@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
@RequestMapping("/diary")
@RequiredArgsConstructor
public class MealController {
    private final DeleteMealUseCase deleteMealUseCase;
    private final CreateMealUseCase createMealUseCase;

    private final GetMealsUseCase getMealsUseCase;
    final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    final CorsConfiguration config = new CorsConfiguration();
    @GetMapping("/{id}/{filter}")
    public ResponseEntity<GetMealsResponse> getMeals(
            @PathVariable(value = "id") final long id,
            @PathVariable(value = "filter", required = false) final String filter) {
        return ResponseEntity.ok(getMealsUseCase.getMeals(id, filter));
    }

    @DeleteMapping("/{id}")
    @ResponseBody
    public ResponseEntity<Void> deleteMeal(@PathVariable(value = "id") final long id) {
        deleteMealUseCase.deleteMeal(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping
    public ResponseEntity<CreateMealResponse> createMeal(
            @RequestBody @Valid CreateMealRequest createMealRequest) {
        CreateMealResponse response = createMealUseCase.createMeal(createMealRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
}
