package com.example.myfitnesspal.repository;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "meals")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MealEntity {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY )
    @Column(name = "id")
    private Long id;
    @Length(min = 2, max = 50)
    @Column(name = "name")
    private String name;
    @Column(name = "calories")
    private Float calories;
    @OneToMany(cascade = CascadeType.ALL,targetEntity = NutritionEntity.class,fetch = FetchType.EAGER)
    @JoinColumn(name = "meal_id")
    private List<NutritionEntity> totalNutrients;
    @ManyToOne
    @JoinColumn(name = "account_id")
    private AccountEntity account;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getCalories() {
        return calories;
    }

    public void setCalories(Float calories) {
        this.calories = calories;
    }

    public List<NutritionEntity> getTotalNutrients() {
        return totalNutrients;
    }

    public void setTotalNutrients(List<NutritionEntity> totalNutrients) {
        this.totalNutrients = totalNutrients;
    }

    public AccountEntity getAccount() {
        return account;
    }
}
