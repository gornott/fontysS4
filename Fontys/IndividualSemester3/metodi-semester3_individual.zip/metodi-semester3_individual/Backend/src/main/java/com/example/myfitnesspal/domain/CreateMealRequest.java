package com.example.myfitnesspal.domain;

import com.example.myfitnesspal.repository.NutritionEntity;
import com.example.myfitnesspal.repository.UserEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import java.util.List;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateMealRequest {
    private Float calories;
    private String name;
    private List<Nutrient> totalNutrients;
    private Long user_id;


}
